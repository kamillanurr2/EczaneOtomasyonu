﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace YeniEczane
{
    public partial class KasaGiris : Form
    {
        public KasaGiris()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();

        private void button1_Click(object sender, EventArgs e)
        {

            TBLKASA KS = new TBLKASA();
            KS.TARIH = Convert.ToDateTime(dateTimePicker1.Value.ToString());
            KS.MIKTAR = Convert.ToDecimal(textBox2.Text);
            KS.ACIKLAMA = textBox1.Text;
            KS.ISLEM = true;
            db.TBLKASA.Add(KS);
            db.SaveChanges();

            TBLGELIR yeni = new TBLGELIR();

            yeni.ISLEM = "Para  Alındı";
            yeni.YERADI = "KASA";

            yeni.ACIKLAMA = KS.ACIKLAMA;
            yeni.TUTAR = Convert.ToDecimal(KS.MIKTAR);
            yeni.TARIH = Convert.ToDateTime(KS.TARIH);
            db.TBLGELIR.Add(yeni);
            db.SaveChanges();

            
          // ((Kasa)System.Windows.Forms.Application.OpenForms["Kasa"];

            MessageBox.Show("YENİ PARA GİRİŞİNİZ TAMAMLANDI");
            this.Close();
        }
    }
}
