﻿namespace YeniEczane
{
    partial class AnaSayfa
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnaSayfa));
            this.panel1 = new System.Windows.Forms.Panel();
            this.BtnHastaBilgileri = new System.Windows.Forms.Button();
            this.BtnRecete = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BtnDoktor = new System.Windows.Forms.Button();
            this.BtnPersonel = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.BtnFirma = new System.Windows.Forms.Button();
            this.Medical = new System.Windows.Forms.Button();
            this.BtnStok = new System.Windows.Forms.Button();
            this.BtnSatis = new System.Windows.Forms.Button();
            this.BtnMuhasebe = new System.Windows.Forms.Button();
            this.BtnHatirlatici = new System.Windows.Forms.Button();
            this.BtnKasa = new System.Windows.Forms.Button();
            this.BtnGunlukHarcama = new System.Windows.Forms.Button();
            this.BtnCekSenet = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RosyBrown;
            this.panel1.Location = new System.Drawing.Point(-304, 107);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1637, 20);
            this.panel1.TabIndex = 10;
            // 
            // BtnHastaBilgileri
            // 
            this.BtnHastaBilgileri.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnHastaBilgileri.FlatAppearance.BorderSize = 0;
            this.BtnHastaBilgileri.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnHastaBilgileri.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHastaBilgileri.Image = ((System.Drawing.Image)(resources.GetObject("BtnHastaBilgileri.Image")));
            this.BtnHastaBilgileri.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnHastaBilgileri.Location = new System.Drawing.Point(102, 4);
            this.BtnHastaBilgileri.Margin = new System.Windows.Forms.Padding(4);
            this.BtnHastaBilgileri.Name = "BtnHastaBilgileri";
            this.BtnHastaBilgileri.Size = new System.Drawing.Size(90, 95);
            this.BtnHastaBilgileri.TabIndex = 1;
            this.BtnHastaBilgileri.Text = "HASTA BİLGİLERİ";
            this.BtnHastaBilgileri.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnHastaBilgileri.UseVisualStyleBackColor = true;
            this.BtnHastaBilgileri.Click += new System.EventHandler(this.BtnHastaBilgileri_Click);
            // 
            // BtnRecete
            // 
            this.BtnRecete.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnRecete.FlatAppearance.BorderSize = 0;
            this.BtnRecete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnRecete.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnRecete.Image = ((System.Drawing.Image)(resources.GetObject("BtnRecete.Image")));
            this.BtnRecete.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnRecete.Location = new System.Drawing.Point(298, 4);
            this.BtnRecete.Margin = new System.Windows.Forms.Padding(4);
            this.BtnRecete.Name = "BtnRecete";
            this.BtnRecete.Size = new System.Drawing.Size(90, 95);
            this.BtnRecete.TabIndex = 3;
            this.BtnRecete.Text = "İLAÇLAR";
            this.BtnRecete.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnRecete.UseVisualStyleBackColor = true;
            this.BtnRecete.Click += new System.EventHandler(this.BtnRecete_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1480, 1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(-319, -75);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1669, 44);
            this.panel3.TabIndex = 12;
            // 
            // BtnDoktor
            // 
            this.BtnDoktor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnDoktor.FlatAppearance.BorderSize = 0;
            this.BtnDoktor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDoktor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDoktor.Image = ((System.Drawing.Image)(resources.GetObject("BtnDoktor.Image")));
            this.BtnDoktor.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnDoktor.Location = new System.Drawing.Point(200, 4);
            this.BtnDoktor.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDoktor.Name = "BtnDoktor";
            this.BtnDoktor.Size = new System.Drawing.Size(90, 95);
            this.BtnDoktor.TabIndex = 2;
            this.BtnDoktor.Text = "DOKTOR";
            this.BtnDoktor.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnDoktor.UseVisualStyleBackColor = true;
            this.BtnDoktor.Click += new System.EventHandler(this.BtnDoktor_Click);
            // 
            // BtnPersonel
            // 
            this.BtnPersonel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnPersonel.FlatAppearance.BorderSize = 0;
            this.BtnPersonel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnPersonel.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPersonel.Image = ((System.Drawing.Image)(resources.GetObject("BtnPersonel.Image")));
            this.BtnPersonel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnPersonel.Location = new System.Drawing.Point(4, 4);
            this.BtnPersonel.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPersonel.Name = "BtnPersonel";
            this.BtnPersonel.Size = new System.Drawing.Size(90, 95);
            this.BtnPersonel.TabIndex = 0;
            this.BtnPersonel.Text = "PERSONEL \r\n";
            this.BtnPersonel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnPersonel.UseVisualStyleBackColor = true;
            this.BtnPersonel.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel2.Location = new System.Drawing.Point(-304, 135);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1630, 596);
            this.panel2.TabIndex = 11;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.AliceBlue;
            this.tableLayoutPanel1.ColumnCount = 13;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.692307F));
            this.tableLayoutPanel1.Controls.Add(this.BtnFirma, 7, 0);
            this.tableLayoutPanel1.Controls.Add(this.Medical, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnStok, 6, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnHastaBilgileri, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnSatis, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnRecete, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnMuhasebe, 8, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnDoktor, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnPersonel, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnHatirlatici, 12, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnKasa, 9, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnGunlukHarcama, 11, 0);
            this.tableLayoutPanel1.Controls.Add(this.BtnCekSenet, 10, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(9, -4);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1274, 103);
            this.tableLayoutPanel1.TabIndex = 13;
            // 
            // BtnFirma
            // 
            this.BtnFirma.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnFirma.FlatAppearance.BorderSize = 0;
            this.BtnFirma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFirma.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFirma.Image = ((System.Drawing.Image)(resources.GetObject("BtnFirma.Image")));
            this.BtnFirma.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnFirma.Location = new System.Drawing.Point(690, 4);
            this.BtnFirma.Margin = new System.Windows.Forms.Padding(4);
            this.BtnFirma.Name = "BtnFirma";
            this.BtnFirma.Size = new System.Drawing.Size(90, 95);
            this.BtnFirma.TabIndex = 5;
            this.BtnFirma.Text = "FİRMA";
            this.BtnFirma.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnFirma.UseVisualStyleBackColor = true;
            this.BtnFirma.Click += new System.EventHandler(this.BtnFirma_Click);
            // 
            // Medical
            // 
            this.Medical.FlatAppearance.BorderSize = 0;
            this.Medical.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Medical.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Medical.Image = ((System.Drawing.Image)(resources.GetObject("Medical.Image")));
            this.Medical.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Medical.Location = new System.Drawing.Point(396, 4);
            this.Medical.Margin = new System.Windows.Forms.Padding(4);
            this.Medical.Name = "Medical";
            this.Medical.Size = new System.Drawing.Size(90, 95);
            this.Medical.TabIndex = 4;
            this.Medical.Text = "MEDİKAL";
            this.Medical.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.Medical.UseVisualStyleBackColor = true;
            this.Medical.Click += new System.EventHandler(this.Medical_Click);
            // 
            // BtnStok
            // 
            this.BtnStok.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnStok.FlatAppearance.BorderSize = 0;
            this.BtnStok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnStok.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnStok.Image = ((System.Drawing.Image)(resources.GetObject("BtnStok.Image")));
            this.BtnStok.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnStok.Location = new System.Drawing.Point(592, 4);
            this.BtnStok.Margin = new System.Windows.Forms.Padding(4);
            this.BtnStok.Name = "BtnStok";
            this.BtnStok.Size = new System.Drawing.Size(90, 95);
            this.BtnStok.TabIndex = 7;
            this.BtnStok.Text = "STOK";
            this.BtnStok.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnStok.UseVisualStyleBackColor = true;
            this.BtnStok.Click += new System.EventHandler(this.BtnStok_Click);
            // 
            // BtnSatis
            // 
            this.BtnSatis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnSatis.FlatAppearance.BorderSize = 0;
            this.BtnSatis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSatis.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSatis.Image = ((System.Drawing.Image)(resources.GetObject("BtnSatis.Image")));
            this.BtnSatis.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnSatis.Location = new System.Drawing.Point(494, 4);
            this.BtnSatis.Margin = new System.Windows.Forms.Padding(4);
            this.BtnSatis.Name = "BtnSatis";
            this.BtnSatis.Size = new System.Drawing.Size(90, 95);
            this.BtnSatis.TabIndex = 8;
            this.BtnSatis.Text = "SATIŞ";
            this.BtnSatis.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnSatis.UseVisualStyleBackColor = true;
            this.BtnSatis.Click += new System.EventHandler(this.BtnSatis_Click);
            // 
            // BtnMuhasebe
            // 
            this.BtnMuhasebe.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnMuhasebe.FlatAppearance.BorderSize = 0;
            this.BtnMuhasebe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMuhasebe.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMuhasebe.Image = ((System.Drawing.Image)(resources.GetObject("BtnMuhasebe.Image")));
            this.BtnMuhasebe.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnMuhasebe.Location = new System.Drawing.Point(788, 4);
            this.BtnMuhasebe.Margin = new System.Windows.Forms.Padding(4);
            this.BtnMuhasebe.Name = "BtnMuhasebe";
            this.BtnMuhasebe.Size = new System.Drawing.Size(90, 95);
            this.BtnMuhasebe.TabIndex = 10;
            this.BtnMuhasebe.Text = "MUHASEBE";
            this.BtnMuhasebe.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnMuhasebe.UseVisualStyleBackColor = true;
            this.BtnMuhasebe.Click += new System.EventHandler(this.BtnMuhasebe_Click);
            // 
            // BtnHatirlatici
            // 
            this.BtnHatirlatici.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnHatirlatici.FlatAppearance.BorderSize = 0;
            this.BtnHatirlatici.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnHatirlatici.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnHatirlatici.Image = ((System.Drawing.Image)(resources.GetObject("BtnHatirlatici.Image")));
            this.BtnHatirlatici.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnHatirlatici.Location = new System.Drawing.Point(1180, 4);
            this.BtnHatirlatici.Margin = new System.Windows.Forms.Padding(4);
            this.BtnHatirlatici.Name = "BtnHatirlatici";
            this.BtnHatirlatici.Size = new System.Drawing.Size(90, 95);
            this.BtnHatirlatici.TabIndex = 9;
            this.BtnHatirlatici.Text = "HATIRLATICI";
            this.BtnHatirlatici.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnHatirlatici.UseVisualStyleBackColor = true;
            this.BtnHatirlatici.Click += new System.EventHandler(this.BtnHatirlatici_Click);
            // 
            // BtnKasa
            // 
            this.BtnKasa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnKasa.FlatAppearance.BorderSize = 0;
            this.BtnKasa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnKasa.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKasa.Image = ((System.Drawing.Image)(resources.GetObject("BtnKasa.Image")));
            this.BtnKasa.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnKasa.Location = new System.Drawing.Point(886, 4);
            this.BtnKasa.Margin = new System.Windows.Forms.Padding(4);
            this.BtnKasa.Name = "BtnKasa";
            this.BtnKasa.Size = new System.Drawing.Size(90, 95);
            this.BtnKasa.TabIndex = 11;
            this.BtnKasa.Text = "KASA";
            this.BtnKasa.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnKasa.UseVisualStyleBackColor = true;
            this.BtnKasa.Click += new System.EventHandler(this.BtnKasa_Click);
            // 
            // BtnGunlukHarcama
            // 
            this.BtnGunlukHarcama.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnGunlukHarcama.FlatAppearance.BorderSize = 0;
            this.BtnGunlukHarcama.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnGunlukHarcama.Font = new System.Drawing.Font("Century Gothic", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnGunlukHarcama.Image = ((System.Drawing.Image)(resources.GetObject("BtnGunlukHarcama.Image")));
            this.BtnGunlukHarcama.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnGunlukHarcama.Location = new System.Drawing.Point(1082, 4);
            this.BtnGunlukHarcama.Margin = new System.Windows.Forms.Padding(4);
            this.BtnGunlukHarcama.Name = "BtnGunlukHarcama";
            this.BtnGunlukHarcama.Size = new System.Drawing.Size(90, 95);
            this.BtnGunlukHarcama.TabIndex = 13;
            this.BtnGunlukHarcama.Text = "GÜNCÜK HARCAMA";
            this.BtnGunlukHarcama.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnGunlukHarcama.UseVisualStyleBackColor = true;
            this.BtnGunlukHarcama.Click += new System.EventHandler(this.BtnGunlukHarcama_Click);
            // 
            // BtnCekSenet
            // 
            this.BtnCekSenet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnCekSenet.FlatAppearance.BorderSize = 0;
            this.BtnCekSenet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnCekSenet.Font = new System.Drawing.Font("Century Gothic", 9.27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCekSenet.Image = ((System.Drawing.Image)(resources.GetObject("BtnCekSenet.Image")));
            this.BtnCekSenet.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnCekSenet.Location = new System.Drawing.Point(984, 4);
            this.BtnCekSenet.Margin = new System.Windows.Forms.Padding(4);
            this.BtnCekSenet.Name = "BtnCekSenet";
            this.BtnCekSenet.Size = new System.Drawing.Size(90, 95);
            this.BtnCekSenet.TabIndex = 12;
            this.BtnCekSenet.Text = "ÇEK-SENET";
            this.BtnCekSenet.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnCekSenet.UseVisualStyleBackColor = true;
            this.BtnCekSenet.Click += new System.EventHandler(this.BtnCekSenet_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(1286, -4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 34);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 100;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // AnaSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1314, 657);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AnaSayfa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BtnHastaBilgileri;
        private System.Windows.Forms.Button BtnRecete;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button BtnDoktor;
        private System.Windows.Forms.Button BtnPersonel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button BtnFirma;
        private System.Windows.Forms.Button Medical;
        private System.Windows.Forms.Button BtnStok;
        private System.Windows.Forms.Button BtnSatis;
        private System.Windows.Forms.Button BtnMuhasebe;
        private System.Windows.Forms.Button BtnHatirlatici;
        private System.Windows.Forms.Button BtnKasa;
        private System.Windows.Forms.Button BtnGunlukHarcama;
        private System.Windows.Forms.Button BtnCekSenet;
    }
}

