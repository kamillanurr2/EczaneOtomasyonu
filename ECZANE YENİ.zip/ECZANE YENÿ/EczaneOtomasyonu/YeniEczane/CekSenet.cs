﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class CekSenet : Form
    {
        public CekSenet()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();

        public void ceksenet()
        {
            var deg = from x in db.TBLCEKSENET
                      select new
                      {
                          x.ID,
                          x.FIRMA,
                          TUR = x.TUR == "ÇEK" ? " ÇEK" : " SENET",
                          x.YAZMATARIHI,
                          x.ODEMETARIHI,
                          x.ACIKLAMA,
                          DURUM = x.DURUMU == false ? " ÖDENMEDİ" : " ÖDENDİ",
                          x.TUTAR
                      };
            dataGridView1.DataSource = deg.ToList();
            textBox3.Text = deg.Sum(x => x.TUTAR).ToString();
        }
        private void CekSenet_Load(object sender, EventArgs e)
        {
            ceksenet();

            var h = db.TBLCEKSENET.OrderBy(x => x.YAZMATARIHI).FirstOrDefault();
            label1.Text = h.FIRMA.ToString();
            label2.Text = h.ID.ToString();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            CekSenetYAZ pe = new CekSenetYAZ();
            pe.ShowDialog();
        }

        private void texttc_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLCEKSENET
                           where x.FIRMA.ToString().Contains(texttc.Text.ToLower())
                           select new
                           {
                               x.ID,
                               x.FIRMA,
                               TUR = x.TUR == "ÇEK" ? " ÇEK" : " SENET",
                               x.YAZMATARIHI,
                               x.ODEMETARIHI,
                               x.ACIKLAMA,
                               DURUM = x.DURUMU == false ? " ÖDENMEDİ" : " ÖDENDİ",
                               x.TUTAR
                           };

            dataGridView1.DataSource = degerler.ToList();

            if (texttc.Text == "")
            {
                ceksenet();
            }
        }
        int secilenid;
        int firmaid;

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secılensatır = dataGridView1.SelectedCells[0].RowIndex;
            secilenid= Convert.ToInt32(dataGridView1.Rows[secılensatır].Cells[0].Value.ToString());
            var bul = db.TBLCEKSENET.Find(secilenid);
            label1.Text = bul.FIRMA.ToString();
            label2.Text=bul.ID.ToString();
            firmaid = Convert.ToInt32(bul.FIRMA);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            String TUR = " ";
            if (radioButton1.Checked) TUR = "ÇEK";
            if (radioButton2.Checked) TUR = "SENET";

            var deg = from x in db.TBLCEKSENET
                      where x.FIRMA == firmaid & x.DURUMU == true & x.TUR == TUR
                      select new
                      {
                          x.ID,
                          x.FIRMA,
                          TUR = x.TUR == "ÇEK" ? " ÇEK" : " SENET",
                          x.YAZMATARIHI,
                          x.ODEMETARIHI,
                          x.ACIKLAMA,
                          DURUM = x.DURUMU == false ? " ÖDENMEDİ" : " ÖDENDİ",
                          x.TUTAR
                      };

            dataGridView1.DataSource = deg.ToList();
            textBox3.Text = deg.Sum(x => x.TUTAR).ToString();

        }

        private void button9_Click(object sender, EventArgs e)
        {
            String TUR = " ";
            if (radioButton1.Checked) TUR = "ÇEK";
            if (radioButton2.Checked) TUR = "SENET";

            var deg = from x in db.TBLCEKSENET
                      where x.FIRMA == firmaid & x.DURUMU == false & x.TUR == TUR
                      select new
                      {
                          x.ID,
                          x.FIRMA,
                          TUR = x.TUR == "ÇEK" ? " ÇEK" : " SENET",
                          x.YAZMATARIHI,
                          x.ODEMETARIHI,
                          x.ACIKLAMA,
                          DURUM = x.DURUMU == false ? " ÖDENMEDİ" : " ÖDENDİ",
                          x.TUTAR
                      };

            dataGridView1.DataSource = deg.ToList();
            textBox3.Text = deg.Sum(x => x.TUTAR).ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var kayıt = db.TBLCEKSENET.Find(secilenid);
            kayıt.DURUMU = true;
            db.SaveChanges();
            MessageBox.Show("ÇEK/SENET ÖDENDİ");
            ceksenet();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var SİLID = secilenid;
            var SİLİNECEK = db.TBLCEKSENET.Find(SİLID);
            DialogResult cevap = MessageBox.Show(SİLİNECEK.ID + " nolu kaydı silmek istediğinize eminmisiniz ", " çek/senet sil ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                db.TBLCEKSENET.Remove(SİLİNECEK);
                db.SaveChanges();

                MessageBox.Show("SİLİNDİ");
                ceksenet();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String TUR = " ";
            if (radioButton1.Checked) TUR = "ÇEK";
            if (radioButton2.Checked) TUR = "SENET";

            var deg = from x in db.TBLCEKSENET
                      where x.DURUMU == false & x.TUR == TUR
                      select new
                      {
                          x.ID,
                          x.FIRMA,
                          TUR = x.TUR == "ÇEK" ? " ÇEK" : " SENET",
                          x.YAZMATARIHI,
                          x.ODEMETARIHI,
                          x.ACIKLAMA,
                          DURUM = x.DURUMU == false ? " ÖDENMEDİ" : " ÖDENDİ",
                          x.TUTAR
                      };

            dataGridView1.DataSource = deg.ToList();
            textBox3.Text = deg.Sum(x => x.TUTAR).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ceksenet();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            String TUR = " ";
            if (radioButton1.Checked) TUR = "ÇEK";
            if (radioButton2.Checked) TUR = "SENET";

            var deg = from x in db.TBLCEKSENET
                      where x.DURUMU == true & x.TUR == TUR
                      select new
                      {
                          x.ID,
                          x.FIRMA,
                          TUR = x.TUR == "ÇEK" ? " ÇEK" : " SENET",
                          x.YAZMATARIHI,
                          x.ODEMETARIHI,
                          x.ACIKLAMA,
                          DURUM = x.DURUMU == false ? " ÖDENMEDİ" : " ÖDENDİ",
                          x.TUTAR
                      };

            dataGridView1.DataSource = deg.ToList();
            textBox3.Text = deg.Sum(x => x.TUTAR).ToString();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker6_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLCEKSENET
                      where x.ODEMETARIHI >= dateTimePicker6.Value && x.ODEMETARIHI <= dateTimePicker5.Value
                      select new
                      {
                          x.ID,
                          x.YAZMATARIHI,
                          x.TUTAR,
                          x.ODEMETARIHI,
                          x.ACIKLAMA,
                          x.FIRMA
                      };
            dataGridView1.DataSource = deg.ToList();
        }
    }
}
