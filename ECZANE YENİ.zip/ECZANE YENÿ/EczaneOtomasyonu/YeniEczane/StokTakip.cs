﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class StokTakip : Form
    {
        ECZANEEntities db =  new ECZANEEntities();  
        public StokTakip()
        {
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        public void stokgetir()
        {
            var degerler = from x in db.TBLSTOKHAREKET
                           select new
                           {
                               
                               x.FIRMAID,
                               x.URUNID,
                               x.TARIH,
                               x.ACIKLAMA,
                               MIKTAR = x.ALINANMIKTAR,
                              x.PERSONEL,
                            
                               x.TUTAR,
                           };
            dataGridView1.DataSource = degerler.OrderByDescending(x => x.TARIH).ToList();

            textBox2.Text = degerler.Sum(x => x.TUTAR).ToString();

        }
        public void firmaodemegetir()
        {
            var degerler = from x in db.TBLFIRMAODEME
                           select new
                           {
                               x.ID,
                               x.TBLFIRMA.FIRMADI,
                               x.TARIH,
                               x.ACIKLAMA,
                               x.TUTAR
                           };
            dataGridView2.DataSource = degerler.OrderByDescending(x => x.ID).ToList();

            textBox1.Text = degerler.Sum(x => x.TUTAR).ToString();
            decimal kalanborc = Convert.ToDecimal(textBox2.Text) - Convert.ToDecimal(textBox1.Text);
        }

        private void StokTakip_Load(object sender, EventArgs e)
        {
            stokgetir();
            firmaodemegetir();
            decimal kalanborc = Convert.ToDecimal(textBox2.Text) - Convert.ToDecimal(textBox1.Text);

            textBox3.Text = kalanborc.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StokaUrunAl fr = new StokaUrunAl();
            fr.TopLevel = false;
            AnaSayfa fm = Application.OpenForms["AnaSayfa"] as AnaSayfa;
            Panel pnl = fm.Controls["panel1"] as Panel;
            fr.TopMost = true;
            fr.Show();
            pnl.Controls.Add(fr);
            fr.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FirmaOdemeYap f = new FirmaOdemeYap();
            f.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //tıklanan satır indexini bulalım
            int secilensatir = dataGridView2.SelectedCells[0].RowIndex;

            //bu satırdaki ödeme numarasını alalım
            int secilenodemeID = Convert.ToInt32(dataGridView2.Rows[secilensatir].Cells[0].Value.ToString());

            //bu ID ye ait odeme kaydını bul
            var silinecekodeme = db.TBLFIRMAODEME.Find(secilenodemeID);

            DialogResult cevap = MessageBox.Show(secilenodemeID + " no'lu ödeme kaydını silmek istediğinize emin misiniz?", "ÖDEME SİL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                db.TBLFIRMAODEME.Remove(silinecekodeme);
                db.SaveChanges();
                MessageBox.Show("Ödeme Kaydınız Silindi");
                firmaodemegetir();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            //tıklanan satır indexini bulalım
            int secilensatir = dataGridView1.SelectedCells[0].RowIndex;

            //bu satırdaki ödeme numarasını alalım
            int secilenodemeID = Convert.ToInt32(dataGridView1.Rows[secilensatir].Cells[0].Value.ToString());

            //bu ID ye ait odeme kaydını bul
            var silinecekodeme = db.TBLSTOKHAREKET.Find(secilenodemeID);

            DialogResult cevap = MessageBox.Show(secilenodemeID + " no'lu Stok kaydını silmek istediğinize emin misiniz?", "STOK HAREKET SİL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                db.TBLSTOKHAREKET.Remove(silinecekodeme);
                db.SaveChanges();
                MessageBox.Show("Stok Kaydınız Silindi");
                stokgetir();
            }
        }
        public void FirmaGoster(int id)
        {
            var degerler = from x in db.TBLSTOKHAREKET
                           where x.FIRMAID == id
                           select new
                           {
                               x.ID,
                               x.FIRMAID,
                               x.URUNID,
                               x.TARIH,
                               x.ACIKLAMA,
                               MIKTAR = x.ALINANMIKTAR,
                               x.PERSONEL,
                               x.TUTAR,
                           };
            dataGridView1.DataSource = degerler.OrderByDescending(x => x.TARIH).ToList();
            textBox2.Text = degerler.Sum(x => x.TUTAR).ToString();


            var degerler1 = from x in db.TBLFIRMAODEME
                            where x.FIRMA == id
                            select new
                            {
                                x.ID,
                                x.TBLFIRMA,
                                x.TARIH,
                                x.ACIKLAMA,
                                x.TUTAR
                            };
            dataGridView2.DataSource = degerler1.OrderByDescending(x => x.ID).ToList();

            textBox1.Text = degerler1.Sum(x => x.TUTAR).ToString();
            decimal kalanborc = Convert.ToDecimal(textBox2.Text) - Convert.ToDecimal(textBox1.Text);
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //tıklanan satır indexini bulalım
            int secilensatir = dataGridView1.SelectedCells[0].RowIndex;

            //bu satırdaki firma adını al
            string secilenfirma = (dataGridView1.Rows[secilensatir].Cells[1].Value.ToString());

            //bu firmanın ID si ni buldum
            int BuFirmaninIDsi = db.TBLFIRMA.Where(x => x.FIRMADI == secilenfirma).FirstOrDefault().ID;

            FirmaGoster(BuFirmaninIDsi);
        }
        private void firma()
        {
            var firma = from x in db.TBLFIRMA
                        select x;
        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.FIRMADI.ToLower().Contains(textBox5.Text.ToLower())
                           select new
                           {
                               FİRMA_NO = x.ID,
                               AD = x.FIRMADI,
                               YETKİLİ = x.YETKILI,
                               ÜNVAN = x.UNVAN,
                               TELEFON = x.TEL1,
                           };
            dataGridView1.DataSource = degerler.OrderBy(y => y.AD).ToList();
            if (textBox5.Text == "")
            {
                firma();
            }
        }
        private void urunler()
        {
            var urun = from x in db.TBLURUN
                       select x;
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLURUN
                           where x.URUN.ToLower().Contains(textBox4.Text.ToLower())
                           select new
                           {
                               urun = x.ID,
                               AD = x.URUN,
                               durum = x.DURUM,
                               stok = x.STOKADET,
                               fşyat = x.SATISFIYATI,
                               x.TARIH
                              
                           };
            dataGridView1.DataSource = degerler.OrderBy(y => y.urun).ToList();
            if (textBox4.Text == "")
            {
                urunler();
            }
        }
             
    }
}
