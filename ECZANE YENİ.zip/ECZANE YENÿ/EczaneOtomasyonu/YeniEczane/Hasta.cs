﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class Hasta : Form

    {
        ECZANEEntities db = new ECZANEEntities();
        public Hasta()
        {
            InitializeComponent();
        }

        public int gelenid;
        int aktıfid = 0;

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void hastagetir()
        {
            //hastaları getirelim
            var hasta = from x in db.TBLHASTA
                        where x.DURUMU == true
                        select new
                        {
                            x.ID,
                            x.AD,
                            x.SOYAD
                        };

            datagridview1.DataSource = hasta.OrderBy(x => x.AD).ToList();
            datagridview1.Columns[0].Width = 20;
            datagridview1.Font = new Font("verdana", 9, FontStyle.Regular);

        }
        public void Hastaodemegetir()
        {
            var degerler = from x in db.TBLHASTAODEME
                           select new
                           {
                               x.ODEMEID,
                               x.ODENEN,
                               x.ACIKLAMA,
                               x.TBLHASTA.AD,
                               x.ODEMETARIHI

                           };
            dataGridView3.DataSource = degerler.ToList();
        }
        public void hastaborcgetir(int id)
        {
            var hastaborc = from x in db.TBLHASTABORC
                            where x.ID == id
                            select new
                            {
                                x.ID,
                                x.TARIH,
                                x.ACIKLAMA,
                                x.BORC

                            };
            dataGridView3.DataSource = hastaborc.ToList();

            //2- Borçlar toplamını yaz
            decimal borctoplami = Convert.ToDecimal(hastaborc.Sum(y => y.BORC));

            textBox2.Text = borctoplami.ToString();

            // 3- id si verilen müşterinin ödemelerini getir
            var odemeler = from x in db.TBLHASTABORC
                           where x.ID == id
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.ACIKLAMA,
                               x.HASTA,
                               x.BORC

                           };
            dataGridView3.DataSource = odemeler.OrderByDescending(c => c.TARIH).ToList();
            //4- ödemeler toplamını da yaz
            decimal odemetoplami = Convert.ToDecimal(odemeler.Sum(y => y.BORC));

            textBox1.Text = odemetoplami.ToString();

            //5- Kalan borcu yaz
            textBox2.Text = (borctoplami - odemetoplami).ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HesabaYaz f = new HesabaYaz();
            f.gelenid = Convert.ToInt32(label8.Text);
            f.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //tıklanan satır indexini bulalım
            int secilensatir = dataGridView3.SelectedCells[0].RowIndex;

            // bu satırdaki ödeme numarasını alalım
            int secilenborcID = Convert.ToInt32(dataGridView3.Rows[secilensatir].Cells[0].Value.ToString());

            // bu ID ye ait odeme kaydını bul
            var silinecekborc = db.TBLHASTABORC.Find(secilenborcID);

            DialogResult cevap = MessageBox.Show(secilenborcID + " no'lu borç kaydını silmek istediğinize emin misiniz?", "BORÇ SİL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                db.TBLHASTABORC.Remove(silinecekborc);
                db.SaveChanges();
                MessageBox.Show("Borç Kaydınız Silindi");
                hastaborcgetir(aktıfid);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            HastaGuncelle hasta = new HastaGuncelle();
            //  hasta.gelemid=Convert.ToInt32 (label8.Text);
            hasta.ShowDialog();
        }

        private void Hasta_Load(object sender, EventArgs e)
        {
            //eğer müşteri tablosu boş değilse ilk kayıt aktif kayıt olsun ödemeler,borçlar,adres ve tel göster!!!
            if (db.TBLHASTA.Count() != 0)   //KAYIT VARSA
            {
                
                hastagetir();
                datagridview1.RowHeadersVisible = false;
                int ilkkayitID = Convert.ToInt32(datagridview1.Rows[0].Cells[0].Value.ToString());

                var bukim = db.TBLHASTA.Find(ilkkayitID);

                label6.Text = bukim.ADRES;
                label7.Text = bukim.TELEFON;
                label11.Text = bukim.ID.ToString();
                aktıfid = ilkkayitID;
                hastaborcgetir(aktıfid);

                
            }

          

        }

        private void button8_Click(object sender, EventArgs e)
        {
            HastaEkle pe = new HastaEkle();
            pe.ShowDialog();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLHASTA
                           where x.AD.ToLower().Contains(textBox11.Text.ToLower())
                           select new
                           {
                               x.TC,
                               x.ID,
                               x.AD,
                               x.SOYAD,
                               x.SOSYALG,
                               x.TELEFON,
                               x.ADRES,
                               x.ILACADI,
                               x.KULLANIMSEKLI,
                               x.ILACBARCOD

                           };

            datagridview1.DataSource = degerler.ToList();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            BorcOde f = new BorcOde();
            gelenid = Convert.ToInt32(label8.Text);
            f.ShowDialog();


        }
        int secilenid;

        public Hasta(int secilenid)
        {
            this.secilenid = secilenid;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            var SİLID = secilenid;
            var SİLİNECEK = db.TBLHASTA.Find(SİLID);
            DialogResult cevap = MessageBox.Show(SİLİNECEK.ID + " nolu kaydı silmek istediğinize eminmisiniz ", " hasta sil ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                db.TBLHASTA.Remove(SİLİNECEK);
                db.SaveChanges();

                MessageBox.Show("SİLİNDİ");
                hastagetir();
            }
            //if (datagridview1.SelectedRows.Count == 0)
            //{
            //    MessageBox.Show("Lütfen silmek istediğiniz hastayı seçin.");
            //    return;
            //}
            //DialogResult result = MessageBox.Show("Seçili hastayı silmek istediğinizden emin misiniz?", "Onay", MessageBoxButtons.YesNo);
            //if (result == DialogResult.Yes)
            //{
            //    // **Seçili satırın indeksini al
            //    int rowIndex = datagridview1.SelectedRows[0].Index;


            //    //** DataGridView'den seçili satırı kaldır
            //    datagridview1.Rows.RemoveAt(rowIndex);

            //    MessageBox.Show("Hasta başarıyla silindi.");
            //    hastagetir();


            //int silid = Convert.ToInt32(label8.Text);
            // var kimbusilinecek = db.TBLHASTA.Find(silid);

            // DialogResult cevap = MessageBox.Show(kimbusilinecek.AD + " " + kimbusilinecek.SOYAD + "Kaydı Silmek İstediğinize Emin Misiniz ? ", "HASTA SİL ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // if (cevap == DialogResult.Yes)
            // {
            //     kimbusilinecek.DURUMU = false;
            //     db.SaveChanges();
            //     MessageBox.Show("Kayıt Silindi");
            //     hastagetir();
            // }
        }

        private void dateTimePicker4_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLHASTAODEME
                      where x.ODEMETARIHI >= dateTimePicker4.Value && x.ODEMETARIHI <= dateTimePicker3.Value
                      select new
                      {
                          x.ODEMEID,
                          x.ODEMETARIHI,
                          x.ODENEN,
                          x.TBLHASTA.AD,
                          x.TBLHASTA.SOYAD,
                          x.ACIKLAMA
                        
                      };
            dataGridView3.DataSource = deg.ToList();
        }

       

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //var tiklanansatir = dataGridView2.CurrentRow;
            //int ilacid = Convert.ToInt32(tiklanansatir.Cells[0].Value.ToString());
            //var ılacbul = db.TBLILAC.Find(ilacid);
            /*Text = persbul.ACIKLAMA;*/

            //txtisebaslama.Text = Convert.ToDateTime(persbul.ISEBASLAMA).ToShortDateString();
            //dateTimePicker10.Text = String.Format("{0:D}", persbul.ISEBASLAMATARIHI);
            //maskedTextBox1.Text = ılacbul.ToString();
            //AD.Text = ılacbul.ILACADI;

            //BARKOD.Text = Convert.ToInt32(ılacbul.BARCODNO).ToString();
            //KULLANIMSEKLI.Text = Convert.ToInt32(ılacbul.KUTUSAYISI).ToString();
            //BARKOD.Text = Convert.ToInt32(ılacbul.BARCODNO).ToString();
          
            //label18.Text = persbul.PERSONELID.ToString();
            //  pictureBox1.ImageLocation = Application.StartupPath + "\\Resimler\\" + persbul.RESIM;


            
        }
      
    }
}
