﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using YeniEczane;
           

namespace YeniEczane
{
    public partial class Ilacalr : Form
    {
        public Ilacalr()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities  ();

        private void IlacGetir()
        {
            var ilaclar = from x in db.TBLILAC
                          select new
                          {
                              x.ID,
                              x.BARCODNO,
                              x.FIYAT,
                              x.KUTUSAYISI,
                              x.ILACADI
                          };
            dataGridView2.DataSource = ilaclar.ToList();

        }



        private void Borc()
        {
            var borc = from x in db.TBLHASTABORC
                       select new
                       {
                           x.HASTA,
                           x.TARIH,
                           x.BORC
                       };
            dataGridView1.DataSource = borc.ToList();
        }

        private void Ilacalr_Load(object sender, EventArgs e)
        {
            IlacGetir();
            Borc();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int miktar = int.Parse(numericUpDown1.Text);
            decimal fiyat = decimal.Parse(textBox4 .Text);
            string ilacadı = textBox3.Text;
            int urunid = int.Parse(label9.Text);
            int firmaid = int.Parse(textBox1.Text);
            var urun = db.TBLURUN.FirstOrDefault(x => x.ID == urunid);
            
            {


                // IlacSat(ilacadı, miktar, fiyat,urunid,firmaid);
                var urunler = db.TBLILAC.FirstOrDefault(x => x.ILACADI == ilacadı);
                if (urun != null)
                {
                    int ıD = urun.ID;
                    int urunId = ıD;
                    IlacSat(firmaid, urunId, fiyat, miktar);
                }
                else
                {
                    MessageBox.Show("İlaç Bulunamadı");
                }
            }
        }

        private void IlacSat(int firmaid, int urunId, decimal fiyat, int miktar)
        {
            throw new NotImplementedException();
        }

        public void IlacSat(int miktar ,int firmaid, decimal fiyat,string ilacadı , int urunid)
        {
            using(var db = new ECZANEEntities())
            {
                var yenisatis = new TBLSATIS
                {
                    TUTAR = fiyat,
                    ADET = miktar,
                    TARIH = DateTime.Now,
                    URUNID = urunid,
                    SATISID = firmaid
                };

                db.TBLSATIS.Add(yenisatis);
                db.SaveChanges();

                var urunn = db.TBLURUN.FirstOrDefault(x=>x.ID == urunid);
                if (urunn != null)
                {
                    urunn.STOKADET -= miktar;
                    db.SaveChanges() ;

                }

                var satislar = from x in db.TBLSATIS
                               where x.HASTAID == firmaid
                               select new
                               {
                                   no = x.HASTAID,
                                   x.TARIH,

                               };
                              
            }
        }
    }
}
