﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class Doktor : Form
    {
        public Doktor()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();

        public void DoktorListele()
        {
            var degerler = from x in db.TBLDOKTOR
                           select new
                           {
                               x.ID,
                               x.DOKTORADISOYADI,
                               x.HASTANE,
                               x.DIPLOMA
                           };
            dataGridView1.DataSource = degerler.ToList();

        }

        private void Doktor_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = db.TBLDOKTOR.ToList();  //DoktorListele();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            DoktorEkle d = new DoktorEkle();
            d.ShowDialog();
        }

      

        private void button2_Click(object sender, EventArgs e)
        {

            DoktorGuncelle form = new DoktorGuncelle();
            form.TopLevel = false;
            panel2.Controls.Add(form);
            //  form.d = Convert.ToInt32(label6.Text);
            form.Show();
            form.TopMost = true;
            form.BringToFront();
        }
        private void doktorgetir()
        {
            var doktor = from x in db.TBLDOKTOR
                         select new
                         {
                             x.ID,
                             x.DOKTORADISOYADI,
                             x.HASTANE,
                             x.DIPLOMA,
                             x.TARIH,
                             x.ALANI
                         };
            dataGridView1.DataSource = doktor.ToList();
        }
        private void textBox11_TextChanged_1(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLDOKTOR
                           where x.DOKTORADISOYADI.ToLower().Contains(textBox11.Text.ToLower())
                           select new
                           {
                               x.ID,
                               AD = x.DOKTORADISOYADI,
                               hastane = x.HASTANE,
                               diploma = x.DIPLOMA,

                           };
            dataGridView1.DataSource = degerler.OrderBy(y => y.AD).ToList();
            if (textBox11.Text == "")
            {
                doktorgetir();
            }

            //int id = int.Parse(lblid.Text);
            //var models = db.TBLDOKTOR.FirstOrDefault(x => x.ID == id);

            //models.DOKTORADISOYADI = AD.Text;
            //models.DOKTORADISOYADI = SOYAD.Text;
            //models.HASTANE = txthastane.Text;
            //models.ALANI = Alanı.Text;

            //int departman;
            //if (int.TryParse(Alanı.Text, out departman))
            //{
            //    models.ALANI = Alanı.ToString();
            //}




            //DoktorListele();

        }

        private void dateTimePicker3_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLDOKTOR
                      where x.TARIH >= dateTimePicker3.Value && x.TARIH <= dateTimePicker4.Value
                      select new
                      {
                          x.ID,
                          x.HASTANE,
                          x.TARIH,
                          x.DIPLOMA,
                          x.DOKTORADISOYADI
                      };
            dataGridView1.DataSource = deg.ToList();
        }
        int secilenid;
     

       

        private void button6_Click_1(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLDOKTOR
                           where x.TARIH >= dateTimePicker3.Value && x.TARIH <= dateTimePicker4.Value
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.DOKTORADISOYADI,
                               x.ALANI,
                               x.HASTANE,
                               x.DIPLOMA
                           };

            dataGridView1.DataSource = degerler.ToList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var SİLID = secilenid;
            var SİLİNECEK = db.TBLDOKTOR.Find(SİLID);

            DialogResult cevap = MessageBox.Show(SİLİNECEK.ID + " nolu kaydı silmek istediğinize eminmisiniz ", " Doktor sil ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                db.TBLDOKTOR.Remove(SİLİNECEK);
                db.SaveChanges();

                MessageBox.Show("SİLİNDİ");
                DoktorListele();
            }
        }
    }

 }

