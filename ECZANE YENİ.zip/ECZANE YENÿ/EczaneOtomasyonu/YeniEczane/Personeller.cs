﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core.Common.CommandTrees.ExpressionBuilder;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class Personeller : Form
    {
       

        public Personeller()
        {
            InitializeComponent();
        }
        public int gelenadminID;
        ECZANEEntities db = new ECZANEEntities();
        public int Aktif;
        public void PersonelleriGetir()
        {
            var personeller = from x in db.TBLPERSONEL
                              where x.AKTIFMI == true
                              select new
                              {
                                  x.PERSONELID,
                                  x.ADI,
                                  x.SOYADI,
                                  x.TBLDEPARTMAN.DEPARTMAN,
                                  x.TC,
                                  x.ISEBASLAMATARIHI


                              };
            dataGridView4.DataSource = personeller.OrderBy(x => x.ADI).ToList();
            dataGridView3.RowHeadersVisible = false;

            //dataGridView3.Columns[0].Visible = false;

        }

        //public Personeller(int gelenperid)
        //{
        //    this.gelenperid = gelenperid;
        //}
        int gelenperid;
        public void odemegoster()
        {
            int id = int.Parse(label18.Text);

            var odemeler = from x in db.TBLPERSONELODEME
                           where x.PERSONEL == id
                           select new
                           {
                               x.ID,
                               x.ACIKLAMA,
                               x.TUR,
                               x.ISLEMTARIHI,
                               x.ODENEN
                           };
            dataGridView3.DataSource = odemeler.OrderByDescending(x => x.ISLEMTARIHI).ToList();

            txttoplamodeme.Text = odemeler.Sum(x => x.ODENEN).ToString();
        }
        
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            //if (db.TBLPERSONEL.Count() != 0)
            //{
            //    PersonelleriGetir();

            //    dataGridView4.RowHeadersVisible=false;
            //    var ilkkayitid = Convert.ToInt32(dataGridView1.Rows[0].Cells[0].Value.ToString());
            //    Aktif = ilkkayitid;

            //    var ilkayit = db.TBLPERSONEL.OrderBy(x=>x.ADI).FirstOrDefault();
            //    txtAd.Text = ilkayit.ADI;
            //    txtSoyad.Text = ilkayit.SOYADI;
            //    txtTC.Text = ilkayit.TC;
            //    txtTel.Text = ilkayit.TELEFON;
            //    txtAdres.Text = ilkayit.ADRES;
            //    txtEmail.Text = ilkayit.MAIL;
            //    txtGorev.Text = ilkayit.TBLDEPARTMAN.DEPARTMAN.ToString();
            //    dateTimePicker1.Value = Convert.ToDateTime(ilkayit.ISEBASLAMATARIHI.ToString());
            //    txtMaas.Text=ilkayit.MAAS.ToString();
            //    label18.Text = ilkayit.PERSONELID.ToString();

            //    //if (ilkayit.FOTOGRAF != "NULL")
            //    //{
            //    //    pictureBox2.ImageLocation = Application.StartupPath + "\\Resimler\\" + ilkayit.FOTOGRAF;
            //    //}
            //    odemegetir(Aktif);


            //}





        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLPERSONEL
                           where x.AKTIFMI == true
                           where x.ADI.ToLower().Contains(textBox4.Text.ToLower())
                           select new
                           {
                               personelno = x.PERSONELID,
                               personeltc = x.TC,
                               isim = x.ADI,
                               soyadı = x.SOYADI,
                               isebaslama = x.ISEBASLAMATARIHI,
                               gorev = x.TBLDEPARTMAN.DEPARTMAN
                           };
            dataGridView3.DataSource = degerler.OrderBy(x => x.isim).ToList();
            if (textBox4.Text == "")
            {
                PersonelleriGetir();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView4.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen silmek istediğiniz personeli seçin.");
                return;
            }

            //** Kullanıcıdan silme işlemini onaylamasını iste
            DialogResult result = MessageBox.Show("Seçili personeli silmek istediğinizden emin misiniz?", "Onay", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                // **Seçili satırın indeksini al
                int rowIndex = dataGridView4.SelectedRows[0].Index;

                int silID = Convert.ToInt32(label18.Text);
                var KİMMİSBUSİLİNECEK = db.TBLPERSONELODEME.Find(silID);
                DialogResult CEVAP = MessageBox.Show(KİMMİSBUSİLİNECEK.PERSONEL + "  SİLMEK İSTEDİĞİNİZE EMİNMİSİNİZ", "ÖDEME SİL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (CEVAP == DialogResult.Yes)
                {
                    db.TBLPERSONELODEME.Remove(KİMMİSBUSİLİNECEK);
                    db.SaveChanges();
                    MessageBox.Show("  KAYIIT SİLİNDİ");
                    PersonelleriGetir();
                }
                MessageBox.Show("Personel başarıyla silindi.");

            }
        }

        private DataGridViewRowCollection GetRows(DataGridView dataGridView4)
        {
            return dataGridView4.Rows;
        }

        private void button5_Click(object sender, EventArgs e, DataGridView dataGridView4, DataGridViewRowCollection rows)
        {
            // **Eğer hiçbir satır seçilmediyse işlem yapma
            if (dataGridView4.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen silmek istediğiniz personeli seçin.");
                return;
            }

            //** Kullanıcıdan silme işlemini onaylamasını iste
            DialogResult result = MessageBox.Show("Seçili personeli silmek istediğinizden emin misiniz?", "Onay", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                // **Seçili satırın indeksini al
                int rowIndex = dataGridView4.SelectedRows[0].Index;
                rows.RemoveAt(rowIndex);

                MessageBox.Show("Personel başarıyla silindi.");
                //int silID = Convert.ToInt32(label18.Text);
                //var KİMMİSBUSİLİNECEK = db.TBLPERSONELODEME.Find(silID);
                //DialogResult CEVAP = MessageBox.Show(KİMMİSBUSİLİNECEK.PERSONEL + "  SİLMEK İSTEDİĞİNİZE EMİNMİSİNİZ", "ÖDEME SİL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                //if (CEVAP == DialogResult.Yes)
                //{
                //    db.TBLPERSONELODEME.Remove(KİMMİSBUSİLİNECEK);
                //    db.SaveChanges();
                //    MessageBox.Show("  KAYIIT SİLİNDİ");
                //    PersonelleriGetir();
                //}
            }
        }
        int secilenpersid;
        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var tiklanansatir = dataGridView4.CurrentRow;
            int secilenpersid = Convert.ToInt32(tiklanansatir.Cells[0].Value.ToString());
            var persbul = db.TBLPERSONEL.Find(secilenpersid);
            /*Text = persbul.ACIKLAMA;*/

            //txtisebaslama.Text = Convert.ToDateTime(persbul.ISEBASLAMA).ToShortDateString();
            dateTimePicker10.Text = String.Format("{0:D}", persbul.ISEBASLAMATARIHI);
            txtTC.Text = persbul.TC;
            txtAd.Text = persbul.ADI;
            txtSoyad.Text = persbul.SOYADI;
            txtAdres.Text = persbul.ADRES;
            txtEmail.Text = persbul.MAIL;
            txtTel.Text = persbul.TELEFON.ToString();
            txtGorev.Text = persbul.TBLDEPARTMAN.DEPARTMAN;
            txtMaas.Text = persbul.MAAS.ToString();
            label18.Text = persbul.PERSONELID.ToString();
            //  pictureBox1.ImageLocation = Application.StartupPath + "\\Resimler\\" + persbul.RESIM;


            odemegoster();



            //int secılensatır = dataGridView4.SelectedCells[0].RowIndex;
            //int secilenperıd = Convert.ToInt32(dataGridView4.Rows[secılensatır].Cells[0].Value.ToString());
            //var bul = db.TBLPERSONELODEME.Find(secilenperıd);
            //label18.Text = bul.ID.ToString();
        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {
            

            PersonelleriGetir();

            if (db.TBLPERSONEL.Count() != 0)
            {
                label18.Text = dataGridView4.Rows[0].Cells[0].Value.ToString();
                //odemegoster(Convert.ToInt32(label18.Text));
                dataGridView4.Columns[0].Width = 60;
                dataGridView4.Font = new Font("verdana", 11, FontStyle.Regular);
                dataGridView4.Columns[0].Width = 50;

                //dataGridView4.RowHeadersVisible = false;
                //var ilkkayitid = Convert.ToInt32(dataGridView4.Rows[0].Cells[0].Value.ToString());
                //Aktif = ilkkayitid;

                //var ilkayit = db.TBLPERSONEL.OrderBy(x => x.ADI).FirstOrDefault();
                //txtAd.Text = ilkayit.ADI;
                //txtSoyad.Text = ilkayit.SOYADI;
                //txtTC.Text = ilkayit.TC;
                //txtTel.Text = ilkayit.TELEFON;
                //txtAdres.Text = ilkayit.ADRES;
                //txtEmail.Text = ilkayit.MAIL;
                //txtGorev.Text = ilkayit.TBLDEPARTMAN.DEPARTMAN.ToString();
                //dateTimePicker1.Value = Convert.ToDateTime(ilkayit.ISEBASLAMATARIHI.ToString());
                //txtMaas.Text = ilkayit.MAAS.ToString();
                //label18.Text = ilkayit.PERSONELID.ToString();

                ////if (ilkayit.FOTOGRAF != "NULL")
                ////{
                ////    pictureBox2.ImageLocation = Application.StartupPath + "\\Resimler\\" + ilkayit.FOTOGRAF;
                ////}
                odemegoster();


            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            PersonelEkle pe = new PersonelEkle();
            pe.ShowDialog();
            //PersonelEkle PE = new PersonelEkle();
            //PE.TopLevel = false;
            //Personeller FM = System.Windows.Forms.Application.OpenForms["Personeller"] as
            //   Personeller;
            //Panel panel = FM.Controls["panel2"] as Panel;
            //PE.TopMost = true;
            //PE.Show();
            //panel.Controls.Add(PE);
            //PE.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PersonelOdemeBilgiler f = new PersonelOdemeBilgiler();
            var tiklanansatir = dataGridView4.CurrentRow;
            int secilenpersid = Convert.ToInt32(tiklanansatir.Cells[0].Value.ToString());
            //  f.gelenpersonelid = secilenpersid;
            //f.gelenpersonelid = Convert.ToInt32(label11.Text);
            f.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLPERSONELODEME
                           where x.ISLEMTARIHI >= dateTimePicker7.Value && x.ISLEMTARIHI <= dateTimePicker6.Value
                           select new
                           {
                               x.ID,
                               x.ISLEMTARIHI,
                               x.TUR,
                               x.PERSONEL,
                               x.ODENEN
                           };

            dataGridView3.DataSource = degerler.ToList();
            txttoplamodeme.Text = Convert.ToDecimal(degerler.Sum(x => x.ODENEN)).ToString() + " ₺";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int id = int.Parse(label18.Text);
            var models = db.TBLPERSONEL.FirstOrDefault(x=>x.PERSONELID==id);

            models.ADI = txtAd.Text;
            models.SOYADI = txtSoyad.Text;
            models.TC = txtTC.Text;
            models.ADRES= txtAdres.Text;
            models.TELEFON = txtTel.Text;
            models.MAIL = txtEmail.Text;
            int departman;
            if (int.TryParse(txtGorev.Text,out departman))
            {
                models.DEPARTMAN = departman;
            }
            // models.DEPARTMAN =Convert.ToInt32( );
            int maas;
            if (int.TryParse(txtMaas.Text, out maas))
            {
                models.MAAS = maas;
            }
          //  models.MAAS =Convert.ToInt32( txtMaas.Text);
            models.ISEBASLAMATARIHI =Convert.ToDateTime( dateTimePicker10.Text);



            PersonelleriGetir();

            //if (dataGridView4.SelectedRows.Count > 0)
            //{
            //    // Seçili satırın indeksini al
            //    int rowIndex = dataGridView4.SelectedRows[0].Index;

            //    // TextBox'lardaki verilerle DataGridView'deki satırı güncelle
            //    dataGridView4.Rows[rowIndex].Cells["Ad"].Value = txtAd.Text;
            //    dataGridView4.Rows[rowIndex].Cells["Soyad"].Value = txtSoyad.Text;
            //    dataGridView4.Rows[rowIndex].Cells["Pozisyon"].Value = txtGorev.Text;
            //    dataGridView4.Rows[rowIndex].Cells["Pozisyon"].Value = txtTel.Text;
            //    dataGridView4.Rows[rowIndex].Cells["Pozisyon"].Value = txtEmail.Text;
            //    dataGridView4.Rows[rowIndex].Cells["Pozisyon"].Value = txtAdres.Text;
            //    dataGridView4.Rows[rowIndex].Cells["Pozisyon"].Value = txtTC.Text;
            //    dataGridView4.Rows[rowIndex].Cells["Pozisyon"].Value = txtMaas.Text;



            //}
            //else
            //{
            //    MessageBox.Show("Lütfen güncellemek için bir satır seçin.");
            //}
            //PersonelGuncelle form = new PersonelGuncelle();
            //form.TopLevel = false;
            //panel2.Controls.Add(form);
            //form.personelid = Convert.ToInt32(label18.Text);
            //form.Show();
            //form.TopMost = true;
            //form.BringToFront();
        }

        private void dataGridView4_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            txtAd.Text = dataGridView4.CurrentRow.Cells["ADI"].Value.ToString();
        //    label18.Text = dataGridView4.CurrentRow.Cells["ID"].Value.ToString();
            txtSoyad.Text = dataGridView4.CurrentRow.Cells["SOYADI"].Value.ToString();
            txtTC.Text = dataGridView4.CurrentRow.Cells["TC"].Value.ToString();
            txtTel.Text = dataGridView4.CurrentRow.Cells["TELEFON"].Value.ToString();

            if (dataGridView4.CurrentRow.Cells["ADRES"].Value != null)
            {
                txtAdres.Text = dataGridView4.CurrentRow.Cells["ADRES"].Value.ToString();
            }

            txtEmail.Text = dataGridView4.CurrentRow.Cells["MAIL"].Value.ToString();
            pictureBox2.Text = dataGridView4.CurrentRow.Cells["FOTOGRAF"].Value.ToString();
            dateTimePicker10.Text = dataGridView4.CurrentRow.Cells["ISEBASLAMATARIHI"].Value.ToString();
            txtGorev.Text = dataGridView4.CurrentRow.Cells["DEPARTMAN"].Value.ToString();
            txtMaas.Text = dataGridView4.CurrentRow.Cells["MAAS"].Value.ToString();

        }

        private void Personeller_Load(object sender, EventArgs e)
        {
          
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            PersonelEkle pe = new PersonelEkle();
            pe.ShowDialog();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            PersonelGuncelle fr = new PersonelGuncelle();
       //     fr.personelid = Convert.ToInt32(label18.Text);
            fr.TopLevel = false;
            AnaSayfa fm = System.Windows.Forms.Application.OpenForms["AnaSayfa"] as AnaSayfa;
            Panel pnl = fm.Controls["panel1"] as Panel;
            fr.TopMost = true;
            fr.Show();
            pnl.Controls.Add(fr);
            fr.BringToFront();

        }

        private void label18_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void Personeller_Load_1(object sender, EventArgs e)
        {
            PersonelleriGetir();
            dataGridView4.Columns[0].Width = 50;
            dataGridView4.Columns[3].Width = 100;

            //listedeki ilk personelin diğer bilgilerini textboxta gösterelim

            var ilkpersonel = db.TBLPERSONEL.FirstOrDefault();

            txtAd.Text = ilkpersonel.ADI;
            txtSoyad.Text = ilkpersonel.SOYADI;
            txtTC.Text = ilkpersonel.TC;
            txtAdres.Text = ilkpersonel.ADRES;
            dateTimePicker10.Text = Convert.ToDateTime(ilkpersonel.ISEBASLAMATARIHI).ToShortDateString();
            txtMaas.Text = ilkpersonel.MAAS.ToString() + "  ₺";
            txtTel.Text = ilkpersonel.TELEFON;

            pictureBox2.ImageLocation = System.Windows.Forms.Application.StartupPath + "\\Resimler\\" + ilkpersonel.FOTOGRAF;
            label18.Text = ilkpersonel.PERSONELID.ToString();

            odemegoster();
            //dataGridView3.Columns[0].Width = 50;
            //dataGridView3.Columns[3].Width = 100;
            //dataGridView3.Font = new Font("arial", 10, FontStyle.Bold);
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            PersonelOdemeBilgiler fr = new PersonelOdemeBilgiler();
            fr.ShowDialog(); 
            //fr.gelenperid = Convert.ToInt32(label18.Text);
            //fr.TopLevel = false;
            //AnaSayfa fm = System.Windows.Forms.Application.OpenForms["AnaSayfa"] as AnaSayfa;
            //Panel pnl = fm.Controls["panel1"] as Panel;
            //fr.TopMost = true;
            //fr.ShowDialog();
            //pnl.Controls.Add(fr);
            //fr.BringToFront();
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var odeme = from x in db.TBLPERSONELODEME
                        select new
                        {
                            x.ID,
                            x.PERSONEL,
                            x.ODENEN,
                            x.ISLEMTARIHI,
                            x.ACIKLAMA
                        };
            dataGridView3.DataSource = odeme.ToList();


        }

        private void button6_Click_2(object sender, EventArgs e)
        {
            PersonelEkle pe = new PersonelEkle();
            pe.ShowDialog();
        }

        private void Personeller_Load_2(object sender, EventArgs e)
        {
            PersonelleriGetir();
            //odemegoster();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void button3_Click_2(object sender, EventArgs e)
        {

            PersonelOdemeBilgiler fr = new PersonelOdemeBilgiler();
            fr.ShowDialog(this);
            fr.gelenperid= Convert.ToInt32(label18.Text);
            fr.TopLevel = false;
            //AnaSayfa fm = System.Windows.Forms.Application.OpenForms["AnaSayfa"] as AnaSayfa;
            //Panel pnl = fm.Controls["panel1"] as Panel;
            fr.TopMost = true;
            fr.Show();
            //pnl.Controls.Add(fr);
            //fr.BringToFront();
        }

        private void dataGridView3_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            PersonelGuncelle fr = new PersonelGuncelle();
                fr.personelid = Convert.ToInt32(label18.Text);
            fr.TopLevel = true;
            //AnaSayfa fm = System.Windows.Forms.Application.OpenForms["AnaSayfa"] as AnaSayfa;
            //Panel pnl = fm.Controls["panel1"] as Panel;
            fr.TopMost = true;
            fr.Show();
            //pnl.Controls.Add(fr);
            fr.BringToFront();
        }

        private void dataGridView4_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            var tiklanansatir = dataGridView4.CurrentRow;
            int secilenpersid = Convert.ToInt32(tiklanansatir.Cells[0].Value.ToString());
            var persbul = db.TBLPERSONEL.Find(secilenpersid);
            /*Text = persbul.ACIKLAMA;*/

            //txtisebaslama.Text = Convert.ToDateTime(persbul.ISEBASLAMA).ToShortDateString();
            dateTimePicker10.Text = String.Format("{0:D}", persbul.ISEBASLAMATARIHI);
            txtTC.Text = persbul.TC;
            txtAd.Text = persbul.ADI;
            txtSoyad.Text = persbul.SOYADI;
            txtAdres.Text = persbul.ADRES;
            txtEmail.Text = persbul.MAIL;
            txtTel.Text = persbul.TELEFON.ToString();
            txtGorev.Text = persbul.TBLDEPARTMAN.DEPARTMAN;
            txtMaas.Text = persbul.MAAS.ToString();
            label18.Text = persbul.PERSONELID.ToString();
            //  pictureBox1.ImageLocation = Application.StartupPath + "\\Resimler\\" + persbul.RESIM;


            odemegoster();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            PersonelOdemeBilgiler fr = new PersonelOdemeBilgiler();
           // fr.personelid = Convert.ToInt32(label18.Text);
            fr.TopLevel = true;
            //AnaSayfa fm = System.Windows.Forms.Application.OpenForms["AnaSayfa"] as AnaSayfa;
            //Panel pnl = fm.Controls["panel1"] as Panel;
            fr.TopMost = true;
            fr.Show();
            //pnl.Controls.Add(fr);
            fr.BringToFront();

            

        }

       
    }
}


