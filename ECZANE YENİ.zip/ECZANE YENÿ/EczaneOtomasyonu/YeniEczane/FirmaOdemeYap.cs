﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class FirmaOdemeYap : Form
    {
        public FirmaOdemeYap()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();

        private void FirmaOdemeYap_Load(object sender, EventArgs e)
        {
            FirmaGetir();
        }
        private void FirmaGetir()
        {
            var firma = from x in db.TBLFIRMA
                        where x.DURUM == true
                        select new
                        {
                            x.ID,
                            x.FIRMADI,

                        };
            dataGridView1.DataSource = firma.ToList();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilensatir = dataGridView1.SelectedCells[0].RowIndex;

            int secilenid = Convert.ToInt32(dataGridView1.Rows[secilensatir].Cells[0].Value.ToString());

            string secilenfirma = dataGridView1.Rows[secilensatir].Cells[1].Value.ToString();

            label4.Text = secilenid.ToString();
            lblfirmaadi.Text = secilenfirma;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FirmaEkle f = new FirmaEkle();
            f.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TBLFIRMAODEME yeni = new TBLFIRMAODEME();
            yeni.FIRMA = Convert.ToInt32(label4.Text);
            yeni.TARIH = Convert.ToDateTime(DateTime.Now.ToShortDateString());

            yeni.TUTAR = Convert.ToDecimal(textBox1.Text);
            yeni.ACIKLAMA = textBox3.Text;

            db.TBLFIRMAODEME.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("Yeni Ödeme Tamamlandı");

            ((StokTakip)Application.OpenForms["StokTakip"]).firmaodemegetir();

            this.Close();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.FIRMADI.ToLower().Contains(textBox2.Text.ToLower())
                           select new
                           {
                               FİRMA_NO = x.ID,
                               AD = x.FIRMADI,
                               YETKİLİ = x.YETKILI,
                               ÜNVAN = x.UNVAN,
                               TELEFON = x.TEL1,


                           };
            dataGridView1.DataSource = degerler.OrderBy(y => y.AD).ToList();
            if (textBox2.Text == "")
            {
                FirmaGetir();
            }
        }
    }
}
