﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class GunlukHarcama : Form
    {
        ECZANEEntities db = new ECZANEEntities();
        public GunlukHarcama()
        {
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void gunlukharcama()
        {
            var harcama = from x in db.TBLGUNLUKHARCAMALAR
                          select new
                          {
                              x.HARCAMAID,
                              x.HARCAMATARIHI,
                              x.HARCAMAYAPILANYER,
                              x.MIKTAR,
                              x.ACIKLAMA,
                              x.ODEMETURU
                          };
            dataGridView1.DataSource = harcama.ToList();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLGUNLUKHARCAMALAR
                           where x.HARCAMATARIHI >= dateTimePicker6.Value && x.HARCAMATARIHI <= dateTimePicker5.Value
                           select new
                           {
                               x.HARCAMAID,
                               x.HARCAMATARIHI,
                               x.HARCAMAYAPILANYER,
                               x.MIKTAR,
                               x.ODEMETURU,
                               x.ACIKLAMA

                           };
            dataGridView1.DataSource = degerler.ToList();   
        }

        private void button3_Click(object sender, EventArgs e)
        {
            HarcamYap pe = new HarcamYap();
            pe.ShowDialog();
            gunlukharcama();
            //HarcamYap form = new HarcamYap();
            //form.TopLevel = false;
            //panel1.Controls.Add(form);
            //form.Show();
            //form.TopMost = true;
            //form.BringToFront();
        }

        private void GunlukHarcama_Load(object sender, EventArgs e)
        {
            gunlukharcama();
        }
        public void HarcamaEkle(HarcamYap harcama)
        {
            harcama.AddOwnedForm(harcama);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult cevap = MessageBox.Show(" HARCAMAYI SİLMEK İSTEDİĞİNİZE EMİNMİSİNİZ?", "HARCAMA SİLME", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                var s = db.TBLGUNLUKHARCAMALAR.Find(Convert.ToInt32(label6.Text));
                db.TBLGUNLUKHARCAMALAR.Remove(s);
                db.SaveChanges();
                MessageBox.Show("HARCAMA SİLİNDİ");
                gunlukharcama();
            }
        }
      
        private void dateTimePicker6_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLGUNLUKHARCAMALAR
                      where x.HARCAMATARIHI >= dateTimePicker6.Value && x.HARCAMATARIHI <= dateTimePicker5.Value
                      select new
                      {
                          x.HARCAMAID,
                          x.HARCAMATARIHI,
                          x.MIKTAR,
                          x.HARCAMAYAPILANYER,
                          x.ACIKLAMA
                         
                      };
            dataGridView1.DataSource = deg.ToList();
        }
    }
}
