﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class StokaUrunAl : Form
    {
        public StokaUrunAl()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        private void StokaUrunAl_Load(object sender, EventArgs e)
        {
            var urunler = from x in db.TBLURUN
                          where x.DURUM == true
                          select x;
            comboBox1.DataSource = urunler.ToList();
            comboBox1.DisplayMember = "URUNADI";
            comboBox1.ValueMember = "URUNID";
            comboBox1.Text = "Seçiniz";
            firmagetir();
        }
        public void firmagetir()
        {
            var degerler = from x in db.TBLFIRMA
                           where x.DURUM == true
                           select new
                           {
                               x.ID,
                               x.FIRMADI
                           };
            dataGridView1.DataSource = degerler.ToList();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilensatir = dataGridView1.SelectedCells[0].RowIndex;
            int secilenid = Convert.ToInt32(dataGridView1.Rows[secilensatir].Cells[0].Value.ToString());
            string secilenfirma= dataGridView1.Rows[secilensatir].Cells[1].Value.ToString();

            label2.Text = secilenid.ToString();
            //tbfirma.Text = secilenfirma;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TBLSTOKHAREKET yeni = new TBLSTOKHAREKET();
            yeni.FIRMAID = Convert.ToInt32(label2.Text);
            yeni.URUNID = Convert.ToInt32(comboBox1.SelectedValue.ToString());
            yeni.TARIH = Convert.ToDateTime(dateTimePicker1.Value.ToShortDateString());
            yeni.ACIKLAMA = tbaciklama.Text;
            yeni.ALINANMIKTAR = Convert.ToInt32(numericUpDown1.Value.ToString());
            decimal sf = Convert.ToDecimal(tbsatisfiyati.Text);
            yeni.TUTAR = sf * yeni.ALINANMIKTAR;
            yeni.PERSONEL = 1;
            db.TBLSTOKHAREKET.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("Yeni stok kaydınız tamamlandı");

            ((StokTakip)Application.OpenForms["StokTakip"]).stokgetir();

            this.Close();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int alinacakurunid = Convert.ToInt32(comboBox1.SelectedValue.ToString());

            var urunbul = db.TBLURUN.Find(alinacakurunid);

            tbsatisfiyati.Text = urunbul.SATISFIYATI.ToString();

            decimal tutar = Convert.ToDecimal(numericUpDown1.Value.ToString()) * Convert.ToInt32(urunbul.SATISFIYATI);

            tbtutar.Text = tutar.ToString();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FirmaEkle f = new FirmaEkle (); 
            f.ShowDialog();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.FIRMADI.ToLower().Contains(textBox2.Text.ToLower())
                           select new
                           {
                               FİRMA_NO = x.ID,
                               AD = x.FIRMADI,
                               YETKİLİ = x.YETKILI,
                               ÜNVAN = x.UNVAN,
                               TELEFON = x.TEL1,
                           };
            dataGridView1.DataSource = degerler.OrderBy(y => y.AD).ToList();
            if (textBox2.Text == "")
            {
                firmagetir();
        }   }
    }
}
