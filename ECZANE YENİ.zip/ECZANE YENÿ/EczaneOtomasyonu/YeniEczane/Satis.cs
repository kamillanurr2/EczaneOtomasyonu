﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class Satis : Form
    {
        ECZANEEntities db = new ECZANEEntities();   
        public Satis()
        {
            InitializeComponent();
        }
        private void hastagetir()
        {
            var hasta = from x in db.TBLHASTA
                        select new
                        {
                            x.ID,
                            x.AD,
                            x.SOYAD
                        };
            dataGridView1.DataSource = hasta.ToList();
        }

        private void urungetir()
        {
            var urunler = from x in db.TBLURUN
                          select new
                          {
                              x.ID,
                              x.URUN,
                              x.TBLSATIS,
                              x.DURUM
                          };
            dataGridView2.DataSource = urunler.ToList();
        }
        private void HastaUrunGetir()
        {
            var hasta = from x in db.TBLHASTA
                        select new
                        {
                            x.ID,
                            x.AD,
                            x.SOYAD
                        };
            dataGridView1.DataSource = hasta.ToList();

            var urun = from x in db.TBLURUN
                       where x.DURUM == true
                       select new
                       {
                           x.ID,
                           x.URUN,
                           x.STOKADET
                       };
            dataGridView2.DataSource = urun.ToList();
        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Satis_Load(object sender, EventArgs e)
        {
            HastaUrunGetir();
            urungetir();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TBLSATIS yeni = new TBLSATIS();
            yeni.HASTAID = Convert.ToInt32(label10.Text);
            yeni.URUNID = Convert.ToInt32(label11.Text);
            yeni.ADET = Convert.ToInt32(numericUpDown1.Value);
            yeni.TARIH = Convert.ToDateTime(dateTimePicker1.Value.ToShortDateString());
            yeni.SATISFIYATI = Convert.ToDecimal(tbsatisfiyati.Text);
            yeni.TUTAR = Convert.ToDecimal(tbtutar.Text);
            yeni.PERSONEL = 1;

            if (radioButton1.Checked)   //NAKİT
            {
                yeni.NAKIT = yeni.TUTAR;
            }
            if (radioButton4.Checked)   //KART
            {
                yeni.KART = yeni.TUTAR;
            }
            if (radioButton5.Checked)  //KART NAKİT
            {
                yeni.NAKIT = Convert.ToDecimal(textBox3.Text);
                yeni.KART = Convert.ToDecimal(textBox4.Text);
            }
            if (radioButton2.Checked) //HESABA YAZ
            {
                yeni.NAKIT = 0;
                yeni.KART = 0;
                //bu satışı MÜŞTERİBORÇ tablosuna gönderelim
                TBLHASTABORC m = new TBLHASTABORC();
                m.ID = yeni.SATISID;
                m.BORC = yeni.TUTAR;
                m.TARIH = yeni.TARIH;
                m.ACIKLAMA = yeni.ADET + " adet " + tburun.Text + " aldı";
                db.TBLHASTABORC.Add(m);
                db.SaveChanges();
            }

            db.TBLSATIS.Add(yeni);
            db.SaveChanges();

            //her satılan ürün stoktan düşmeli....
            var stoktandusulecekurunbul = db.TBLURUN.Find(yeni.URUNID);
            stoktandusulecekurunbul.STOKADET = stoktandusulecekurunbul.STOKADET - yeni.ADET;
            db.SaveChanges();
            //__________________________________________

            MessageBox.Show("Satış Kaydedildi");


            //eğer ödeme "hesaba yaz" değilse gelir olarak kasaya gitmeli

            if (radioButton2.Checked == false)
            {
                //bu ödeme kasaya gelir olarak kaydedilsin
                TBLGELIR g = new TBLGELIR();

                g.ACIKLAMA = tbmusteri.Text + " " + yeni.ADET + " adet " + tburun.Text + " aldı";
                g.TUTAR = yeni.TUTAR;
                g.TARIH = yeni.TARIH;
                db.TBLGELIR.Add(g);
                db.SaveChanges();
                //_____________________________________________________
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilensatir = dataGridView1.SelectedCells[0].RowIndex;

            int secilenid =Convert.ToInt32( dataGridView1.Rows[secilensatir].Cells[0].Value.ToString());

            string secilenhasatad = dataGridView1.Rows[secilensatir].Cells[1].Value.ToString();

            string secilenhastasoyad = dataGridView1.Rows[secilensatir].Cells[2].Value.ToString();

            label10.Text = secilenid.ToString();
            tbmusteri.Text = secilenhasatad + " " + secilenhastasoyad;


        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilensatir = dataGridView2.SelectedCells[0].RowIndex;

            int secilenid = Convert.ToInt32(dataGridView2.Rows[secilensatir].Cells[0].Value.ToString());

            string secilenurun = dataGridView2.Rows[secilensatir].Cells[1].Value.ToString();

            label11.Text= secilenid.ToString();
            tburun.Text = secilenurun.ToString();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int urunid = Convert.ToInt32(label11.Text);

            int urunstok = Convert.ToInt32(db.TBLURUN.Find(urunid).STOKADET);

            if (numericUpDown1.Value <= urunstok)
            {
                decimal buurununsatisfiyati = Convert.ToDecimal(db.TBLURUN.Find(urunid).SATISFIYATI);

                tbsatisfiyati.Text = buurununsatisfiyati.ToString();

                decimal tutar = buurununsatisfiyati * numericUpDown1.Value;

                tbtutar.Text = tutar.ToString();
            }
            else
            {
                //stoktan fazla ürünadeti girildiğinde adet stokadet kadar kalsın!!!
                MessageBox.Show("Yeterli stok yok!!!");
                numericUpDown1.Value = urunstok;
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            groupBox4.Visible = true;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox4.Text = (Convert.ToDecimal(tbtutar.Text) - Convert.ToDecimal(textBox3.Text)).ToString();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLHASTA
                           where x.AD.ToUpper().Contains(textBox1.Text.ToUpper())
                           where x.DURUMU == true
                           select new
                           {
                               x.ID,
                               x.AD,
                               x.SOYAD
                           };
            dataGridView1.DataSource = degerler.ToList();

            if (textBox1.Text == "")
            {
                hastagetir();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLURUN
                           where x.URUN.ToUpper().Contains(textBox1.Text.ToUpper())
                           where x.DURUM == true
                           select new
                           {
                               x.ID,
                               x.URUN,
                               x.TARIH
                           };
            dataGridView2.DataSource = degerler.ToList();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            HastaEkle h = new HastaEkle();
            h.ShowDialog();
        }
    }
}
