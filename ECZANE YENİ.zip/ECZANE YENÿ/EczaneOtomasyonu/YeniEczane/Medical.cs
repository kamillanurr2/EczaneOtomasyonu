﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class Medical : Form
    {
        public Medical()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();

        private void MedicalGoster()
        {
            var medical = from x in db.TBLMEDICAL
                          select new
                          {
                              x.ID,
                              x.CIHAZADI,
                              x.TBLFIRMA.FIRMADI,
                              x.KULLANIMAMACI,
                              x.FIYAT,
                              x.URUNLER
                          };
            dataGridView1.DataSource = medical.ToList();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            TBLMEDICAL yeni = new TBLMEDICAL();
            yeni.CIHAZADI = comboBox1.Text;
            yeni. URUNLER = comboBox2.Text;
            db.TBLMEDICAL.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("Başarılı Bir şekilde Kaydedilmiştir");
            MedicalGoster();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Medical_Load(object sender, EventArgs e)
        {
            MedicalGoster();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLMEDICAL
                           where x.CIHAZADI.ToLower().Contains(textBox1.Text.ToLower())
                           select new
                           {
                               x.ID,
                               x.CIHAZADI,
                               x.URUNLER,
                               x.FIRMA,
                               x.FIYAT
                           };
            dataGridView1.DataSource = degerler.OrderBy(y => y.CIHAZADI).ToList();
            if (textBox1.Text == "")
            {
                MedicalGoster();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
