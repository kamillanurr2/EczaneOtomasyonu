﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class FirmaEkle : Form
    {
        ECZANEEntities db = new ECZANEEntities();   
        public FirmaEkle()
        {
            InitializeComponent();
        }

        private void FirmaEkle_Load(int id)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.ID == id
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.FIRMADI,
                               x.TEL1,
                               x.TEL2,
                               x.ADRES,
                               x.MAIL,
                               x.WEB,
                               x.YETKILI,
                               x.ACIKLAMA,
                               x.UNVAN
                           };
        }
        public void FirmaListele(int id)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.ID == id
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.FIRMADI,
                               x.TEL1,
                               x.TEL2,
                               x.ADRES,
                               x.MAIL,
                               x.WEB,
                               x.YETKILI,
                               x.ACIKLAMA,
                               x.UNVAN
                           };
            db.SaveChanges();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtFirmaAdi.Text == "")
            {
                MessageBox.Show("LÜTFEN FİRMA ADINI GİRİNİZ");
            }

            TBLFIRMA yeni = new TBLFIRMA();
            yeni.FIRMADI = txtFirmaAdi.Text;
            yeni.TEL1 = tel1.Text;
            yeni.TEL2 = tel2.Text;
            yeni.ACIKLAMA = acıklama.Text;
            yeni.ADRES = adres.Text;
            yeni.FAX =Convert.ToInt32(fax.Text);
            yeni.MAIL = maıl.Text;
            yeni.UNVAN = unvan.Text;
            yeni.WEB = web.Text;
            yeni.YETKILI = yetkili.Text;
            yeni.DURUM = true;
            yeni.TARIH =Convert.ToDateTime( dateTimePicker1.Text);


            Firma fe = new Firma();
            fe.ShowDialog();
            //((Firma)Application.OpenForms["Firma"]).FirmaGetir();
            //this.Close();
        }

        private void FirmaEkle_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
