﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class HastaEkle : Form
    {
        ECZANEEntities db = new ECZANEEntities();
        public HastaEkle()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HastaEkle_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            TBLHASTA yeni = new TBLHASTA();
            
                yeni.TC = maskedTextBox1.Text;
                yeni.AD = AD.Text;
                yeni.SOYAD = SOYAD.Text;
                yeni.TELEFON = TELEFON.Text;
        //        yeni.DURUMU = Convert.ToBoolean(DURUM.Text);
                yeni.ADRES = ADRES.Text;
                yeni.ILACADI = ILAC.Text;
                yeni.ILACBARCOD = Convert.ToInt32(ILACBARCOD.Text);
                yeni.KULLANIMSEKLI = KULLANIMSEKLI.Text;
            

                db.TBLHASTA.Add(yeni);
                db.SaveChanges();
                MessageBox.Show("Yeni hasta kaydı tamamlandı");

            }
        }
    }
