﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class PersonelEkle : Form
    {

        private List<Personeller> personellistesi = new List<Personeller>();

        public PersonelEkle()
        {
            InitializeComponent();
        }

        ECZANEEntities db = new ECZANEEntities();


        public void PersonelGetir()
        {
            var degerler = from x in db.TBLPERSONEL
                           select new
                           {
                               x.PERSONELID,
                               x.ADI,
                               x.SOYADI,
                               x.ISEBASLAMATARIHI,
                               x.TBLDEPARTMAN.DEPARTMAN,

                           };

           
        }
        private void PersonelEkle_Load(object sender, EventArgs e)
        {
            //vt deki departman listesini comboboxa çekelim

            var depler = from x in db.TBLDEPARTMAN
                         where x.DURUM == true
                         select x;

            comboBox1.DataSource = depler.ToList();
            comboBox1.DisplayMember = "DEPARTMAN";
            comboBox1.ValueMember = "ID";
            comboBox1.Text = "Seçiniz";
        }



        private void button3_Click(object sender, EventArgs e, int? text)
        {
            //dataGridView1.Rows.Add(AD.Text, SOYAD.Text,TC.Text,dateTimePicker5.Text, GOREV.Text,ADRES.Text,TELEF.Text,MAIL.Text,MAAS.Text);
            string resimadi;

            if (label5.Text != "Resim")
            {
                //eğer resim seçildiyse seçilen resim önce Debug klasöründe oluşturduğumuz "Resimler" klasörüne kaydedilsin
                pictureBox3.Image.Save(Application.StartupPath + "\\Resimler\\" + openFileDialog1.SafeFileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                resimadi = label5.Text;
            }
            else
            {
                resimadi = "resimyok.png";
            }
            TBLPERSONEL yp = new TBLPERSONEL();
            yp.ADI = AD.Text;
            yp.ADRES = ADRES.Text;
            yp.TELEFON = TELEF.Text;
            yp.TC = TC.Text;
            yp.MAAS = Convert.ToDecimal(MAAS.Text);
            yp.ISEBASLAMATARIHI = dateTimePicker5.Value;
            //   yp.ACIKLAMA = txtaciklama.Text;
            //  yp.DEPARTMAN = text;
            // yp.RESIM = resimadi;
            db.TBLPERSONEL.Add(yp);
            db.SaveChanges();
            MessageBox.Show("Yeni Personel Ekledim");
            ((Personeller)Application.OpenForms["Personeller"]).PersonelleriGetir();
            this.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    pictureBox3.Image = Image.FromFile(openFileDialog1.FileName);
                    label10.Text = openFileDialog1.SafeFileName;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //eğer maaş ve departman bilgisi girmediyse uyarı versin
            string resimadi;

            if (MAAS.Text == "" || comboBox1.Text == "Seçiniz")
            {
                MessageBox.Show("Departman ve Maaş bilgisini boş geçemezsiniz!!!");
            }
            else
            {
                //yeni personel ekle
                TBLPERSONEL yeni = new TBLPERSONEL();
                yeni.ADI = AD.Text;
                yeni.SOYADI = SOYAD.Text;
                yeni.TC = TC.Text;
                yeni.TELEFON = TELEF.Text;
                yeni.ADRES = ADRES.Text;
                yeni.DEPARTMAN = Convert.ToInt32(comboBox1.SelectedValue.ToString());
                yeni.MAAS = Convert.ToDecimal(MAAS.Text);
                yeni.ISEBASLAMATARIHI = dateTimePicker5.Value;
                yeni.AKTIFMI = true;
                //if (label10.Text == "aa") //resim seçilmemiş
                //{
                //    resimadi = "resimyok.png";
                //}
                //else        //resim seçmişse bu resim debug klasörüne de kaydedilmeli
                //{
                //    resimadi = label10.Text;
                //    pictureBox3.Image.Save(Application.StartupPath + "\\Resimler\\" + openFileDialog1.SafeFileName, System.Drawing.Imaging.ImageFormat.Png);

                //}
                //yeni.FOTOGRAF = resimadi;

                db.TBLPERSONEL.Add(yeni);
                db.SaveChanges();
                MessageBox.Show("yeni Personel Kaydınız Tamamlandı");

                //Form1 deki personelgetir metodunu yenidençağıralım ki listedeki değişiklik görünsün
                ((Personeller)Application.OpenForms["Personeller"]).PersonelleriGetir();
                this.Close();
            }
        }

        private void MAAS_KeyPress(object sender, KeyPressEventArgs e)
        {
            //sadece sayı girişi sağladık
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            AD.Text = "";
            SOYAD.Clear();
            MAAS.Clear();
            TC.Clear();
            ADRES.Clear();
            TELEF.Clear();
            comboBox1.Text = "Seçiniz";
            label10.Text = "aa";
            pictureBox3.Image = null;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
