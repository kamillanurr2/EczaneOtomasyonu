﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class Hatırlatıcı : Form
    {
        ECZANEEntities db = new ECZANEEntities();
        public Hatırlatıcı()
        {
            InitializeComponent();
        }
        private void Hatirilatmagetir()
        {
            var hatirlatici = from x in db.TBLHATIRLATMA
                              select new
                              {
                                  x.ID,
                                  x.KAYITTARIHI,
                                  x.HATIRLATMATARIHI,
                                  x.DURUMU,
                                  x.TURU
                              };
            dataGridView1.DataSource = hatirlatici.ToList();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void Hatırlatıcı_Load(object sender, EventArgs e)
        {
            Hatirilatmagetir();
            //dataGridView1.DataSource = db.TBLHATIRLATMA.ToList();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult cevap = MessageBox.Show("HATIRLATMAYI SİLMEK İSTEDİĞİNİZE EMİNMİSİNİZ?", "HATIRLATMA SİLME", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                var s = db.TBLHATIRLATMA.Find(Convert.ToInt32(label6.Text));
                db.TBLHATIRLATMA.Remove(s);
                db.SaveChanges();
                MessageBox.Show("HATIRLATMA SİLİNDİ");
                Hatirilatmagetir();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            HatirlatmaEkle pe = new HatirlatmaEkle();
            pe.ShowDialog();
        }

        //private void button6_Click(object sender, EventArgs e)
        //{
        //    var degerler = from x in db.persone
        //                   where x.ISLEMTARIHI >= dateTimePicker1.Value && x.ISLEMTARIHI <= dateTimePicker2.Value
        //                   select new
        //                   {
        //                       x.ODEMEID,
        //                       x.ISLEMTARIHI,
        //                       x.ODEMETUR,
        //                       x.PERNO,
        //                       x.ODENEN
        //                   };

        //    dataGridView2.DataSource = degerler.ToList();
        //    txttoplamodenen.Text = Convert.ToDecimal(degerler.Sum(x => x.ODENEN)).ToString() + " ₺";
        //}
    }
}
