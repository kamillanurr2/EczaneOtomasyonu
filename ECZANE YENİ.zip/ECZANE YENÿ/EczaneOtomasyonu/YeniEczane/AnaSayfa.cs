﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class AnaSayfa : Form
    {
        public AnaSayfa()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           button1_Click(sender, e, panel1);
        }

        private void button1_Click(object sender, EventArgs e, Panel panel1)
        {
            Personeller pe = new Personeller();
            pe.ShowDialog();

            //pe.TopLevel = true;
            //panel1.Controls.Add(pe);
            pe.ShowDialog();
            //pe.TopMost = true;
            pe.BringToFront();

        }

        private void BtnDoktor_Click(object sender, EventArgs e)
        {
            Doktor doktorForm = new Doktor();
            doktorForm.ShowDialog();
            Doktor d = new Doktor();
            d.TopLevel = true;
          //  panel1.Controls.Add(d);
            d.ShowDialog();
            d.TopMost = true;
            d.BringToFront();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnHatirlatici_Click(object sender, EventArgs e)
        {
            Hatırlatıcı form =new Hatırlatıcı();
            form.TopLevel = false;
            panel2.Controls.Add(form);
            form.Show();
            form.TopMost = true;
            form.BringToFront();
            //Hatırlatıcı hatirlatmaForm = new Hatırlatıcı();
            //hatirlatmaForm.ShowDialog();
            //Hatırlatıcı hatirlat = new Hatırlatıcı();
            //hatirlat.TopLevel = true;
            //panel2.Controls.Add(hatirlat);
            //hatirlat.ShowDialog();
            //hatirlat.TopMost = true;
            //hatirlat.BringToFront();
        }

        private void BtnHastaBilgileri_Click(object sender, EventArgs e)
        {
            Hasta HastaForm = new Hasta();
            HastaForm.ShowDialog();
            Hasta hast = new Hasta();
            hast.TopLevel = true;
          //  panel1.Controls.Add(hast);
            hast.ShowDialog();
            hast.TopMost = true;
            hast.BringToFront();
        }

        private void BtnRecete_Click(object sender, EventArgs e)
        {
            Ilacalr receteform = new Ilacalr();
            receteform.ShowDialog();
            Ilacalr recet = new Ilacalr();
            recet.TopLevel = true;
          //  panel1.Controls.Add(recet);
            recet.ShowDialog();
            recet.TopMost = true;
            recet.BringToFront();
           
        }

        private void Medical_Click(object sender, EventArgs e)
        {
            Medical medicalform = new Medical();
            medicalform.ShowDialog();
            medicalform.TopLevel = true;
            Medical m = new Medical();
            //panel2.Controls.Add(m);
            m.ShowDialog();
            m.TopMost = true;
            m.BringToFront();
        }

        private void BtnSatis_Click(object sender, EventArgs e)
        {
            Satis satisform = new Satis();
            satisform.ShowDialog();
            satisform.TopLevel = true;
            Satis s = new Satis();
           // panel1.Controls.Add(s);
            s.ShowDialog();
            s.TopMost = true;
            s.BringToFront();
        }

        private void BtnStok_Click(object sender, EventArgs e)
        {
            StokTakip stoktakipform = new StokTakip();
            stoktakipform.ShowDialog();
            StokTakip d = new StokTakip();
            d.TopLevel = true;
           // panel1.Controls.Add(d);
            d.ShowDialog();
            d.TopMost = true;
            d.BringToFront();
        }

        private void BtnMuhasebe_Click(object sender, EventArgs e)
        {
            Muhasebe muhasebeform = new Muhasebe();
            muhasebeform.ShowDialog();
            Muhasebe m = new Muhasebe();
            m.TopLevel = true;
            //panel1.Controls.Add(m);
            m.ShowDialog();
            m.TopMost = true;
            m.BringToFront();
        }

        private void BtnFirma_Click(object sender, EventArgs e)
        {
            Firma firmaform = new Firma();
            firmaform.ShowDialog();
            Firma f = new Firma();
            f.TopLevel = true;
            //panel1.Controls.Add(f);
            f.ShowDialog();
            f.TopMost = true;
            f.BringToFront();
        }

        private void BtnCekSenet_Click(object sender, EventArgs e)
        {
            CekSenet ceksenet = new CekSenet();
            ceksenet.ShowDialog();
            CekSenet cksnt = new CekSenet();
            cksnt.TopLevel = true;
            //panel1.Controls.Add(cksnt);
            cksnt.ShowDialog();
            cksnt.TopMost = true;   
            cksnt.BringToFront();

        }

        private void BtnGunlukHarcama_Click(object sender, EventArgs e)
        {
            GunlukHarcama gunlukharcamaform = new GunlukHarcama();
            gunlukharcamaform.ShowDialog();
            GunlukHarcama d = new GunlukHarcama();
            d.TopLevel = true;
            //panel1.Controls.Add(d);
            d.ShowDialog();
            d.TopMost = true;
            d.BringToFront();
        }

        private void BtnKasa_Click(object sender, EventArgs e)
        {
            Kasa kasaform = new Kasa();
            kasaform.ShowDialog();
            Kasa k = new Kasa();
            k.TopLevel = true;
          //  panel2.Controls.Add(k);
            k.ShowDialog();
            k.TopMost = true;
            k.BringToFront();
        }
    }
}
