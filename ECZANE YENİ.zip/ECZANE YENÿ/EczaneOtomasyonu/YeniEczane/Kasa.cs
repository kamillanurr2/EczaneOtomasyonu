﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class Kasa : Form
    {
        public Kasa()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        private void Kasa_Load(object sender, EventArgs e)
        {
            KasaGoster();

            //var giris = from x in db.TBLKASA
            //           where x.ISLEM=="Para Giriş"
            //           select new
            //           {
            //               x.ID,
            //               x.GIRIS,
            //               x.TARIH,
            //               x.MIKTAR,
            //               x.ACIKLAMA,
            //               x.CIKIS,
            //               x.ISLEM
            //           };
            //dataGridView1.DataSource = giris.ToList();
            //decimal gir  = Convert.ToDecimal(giris.Sum(x => x.MIKTAR));
            //textBox4.Text =gir.ToString();


            //var cıkıs = from x in db.TBLKASA
            //            where x.ISLEM == "Para Çıkışı"
            //            select new
            //            {
            //                x.ID,
            //                x.ISLEM,
            //                x.TARIH,
            //                x.ACIKLAMA,
            //                x.MIKTAR
            //            };
            //dataGridView2.DataSource=cıkıs.ToList();
            //decimal cık = Convert.ToDecimal(cıkıs.Sum(x => x.MIKTAR));
            //textBox5.Text = cık.ToString();

            //textBox6.Text = (gir - cık).ToString();


        }
       
        private void KasaGoster()
        {
            var kasa = from x in db.TBLKASA
                       select new
                       {
                           x.ID,
                           x.GIRIS,
                           x.MIKTAR,
                           x.ACIKLAMA,
                           x.CIKIS,
                           x.TARIH,
                           x.ISLEM
                       };
            dataGridView1.DataSource = kasa.ToList();
            
            dataGridView1.DataSource = kasa.OrderByDescending(x => x.TARIH).ToList();
            dataGridView2.DataSource = kasa.ToList();

            dataGridView2.DataSource = kasa.OrderByDescending(x => x.TARIH).ToList();
        }

        //private void textBox1_TextChanged(object sender, EventArgs e)
        //{
        //    var deg = from x in db.TBLKASA
        //              where x.ISLEM.ToLower().Contains(textBox1.Text.ToLower())
        //              select new
        //              {
        //                  x.ID,
        //                  x.ISLEM,
        //                  x.TARIH,
        //                  x.ACIKLAMA,
        //                  x.MIKTAR
        //              };
        //    dataGridView1.DataSource = deg.ToList();
        //    if (textBox1.Text == "")
        //    {
        //        KasaGoster();
        //    }
        //}

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            KasaGiris form = new KasaGiris();
            form.ShowDialog();
            KasaGoster();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLKASA
                      where x.TARIH >= dateTimePicker2.Value && x.TARIH <= dateTimePicker1.Value
                      select new
                      {
                          x.ID,
                          x.ISLEM,
                          x.TARIH,
                          x.ACIKLAMA,
                          x.MIKTAR
                      };
            dataGridView2.DataSource = deg.ToList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            KasaÇıkış form = new KasaÇıkış();
            form.ShowDialog();
            KasaGoster();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilensatir = dataGridView1.SelectedCells[0].RowIndex;
            int secilenperid = Convert.ToInt32(dataGridView1.Rows[secilensatir].Cells[0].Value.ToString());


            var gırıs = from x in db.TBLKASA
                        where x.ID == secilenperid && x.ISLEM == true
                        select new
                        {
                            x.ID,
                            x.ISLEM,
                            x.TARIH,
                            x.ACIKLAMA,
                            x.MIKTAR
                        };

            decimal gır = Convert.ToDecimal(gırıs.Sum(x => x.MIKTAR));
            textBox7.Text = gır.ToString();

            var cıkıs = from x in db.TBLKASA
                        where x.ID == secilenperid && x.ISLEM == true
                        select new
                        {
                            x.ID,
                            x.ISLEM,
                            x.TARIH,
                            x.ACIKLAMA,
                            x.MIKTAR
                        };

            decimal cık = Convert.ToDecimal(cıkıs.Sum(x => x.MIKTAR));
            textBox3.Text = cık.ToString();

            textBox2.Text = (gır - cık).ToString();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secilensatir = dataGridView2.SelectedCells[0].RowIndex;
            int secilenperid = Convert.ToInt32(dataGridView2.Rows[secilensatir].Cells[0].Value.ToString());


            var gırıs = from x in db.TBLKASA
                        where x.ID == secilenperid && x.ISLEM == true
                        select new
                        {
                            x.ID,
                            x.ISLEM,
                            x.TARIH,
                            x.ACIKLAMA,
                            x.MIKTAR
                        };

            decimal gır = Convert.ToDecimal(gırıs.Sum(x => x.MIKTAR));
            textBox7.Text = gır.ToString();

            var cıkıs = from x in db.TBLKASA
                        where x.ID == secilenperid && x.ISLEM == true
                        select new
                        {
                            x.ID,
                            x.ISLEM,
                            x.TARIH,
                            x.ACIKLAMA,
                            x.MIKTAR
                        };

            decimal cık = Convert.ToDecimal(cıkıs.Sum(x => x.MIKTAR));
            textBox3.Text = cık.ToString();

            textBox2.Text = (cık - gır).ToString();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
