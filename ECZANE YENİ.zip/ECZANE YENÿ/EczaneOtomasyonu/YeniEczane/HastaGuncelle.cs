﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class HastaGuncelle : Form
    {
        ECZANEEntities db = new ECZANEEntities();
        public HastaGuncelle(int gelenid)
        {
            InitializeComponent();
            this.gelenid = gelenid;
        }

        public HastaGuncelle()
        {
        }

        public int hastaid;
        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        int gelenid;
        private void groupBox1_Enter(object sender, EventArgs e)
        {
            maskedTextBox1.Text = maskedTextBox1.Text;
            AD.Text = AD.Text;
            SOYAD.Text = SOYAD.Text;
            SOSYALG.Text = SOSYALG.Text;
            TELEFON.Text = TELEFON.Text;
            DURUM.Text = DURUM.Text;
            ADRES.Text = ADRES.Text;
            BARKOD.Text = BARKOD.Text;
            ILACKULLANIM.Text = ILACKULLANIM.Text;
            KULLANIMSEKLI.Text = KULLANIMSEKLI.Text;

            
        }
        int degeral;
        internal int gelemid;

        private void button8_Click(object sender, EventArgs e)
        {
            int a = int.Parse(label11.Text);
            var bul = db.TBLHASTA.Find(a);
            bul.AD = AD.Text;
            bul.SOYAD = SOYAD.Text;
            bul.SOSYALG = SOSYALG.Text;
            bul.TELEFON = TELEFON.Text;
            bul.DURUMU = bool.Parse(DURUM.Text);
            bul.ADRES = ADRES.Text;
            bul.ILACBARCOD = int.Parse(BARKOD.Text);
            label13.Text = gelenid.ToString();
          
            bul.KULLANIMSEKLI = KULLANIMSEKLI.ToString();

            db.SaveChanges();


            MessageBox.Show("Güncelleme işlemi başarılı bir şekilde yapılmıştır.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            //if (AD.Text == "" || SOYAD.Text == "" || maskedTextBox1.Text == "" || SOSYALG.Text == "" || TELEFON.Text == ""
            //    || DURUM.Text == "" || ADRES.Text == "" || BARKOD.Text == "" || ILACKULLANIM.Text == "" || KULLANIMSEKLI.Text == "")
            //{
            //    MessageBox.Show("Lütfen alanları boş geçmeyiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            //}

            //else
            //{

            // //   int degeral = int.Parse(label10.Text);
            //    var bul = db.TBLDOKTOR.Find(degeral);
            //    bul. = AD.Text;
            //    bul.DOKTORADISOYADI = SOYAD.Text;
            //    bul.HASTANE = txthastane.Text;
            //    bul.ALANI = İŞEB.Text;

            //    db.SaveChanges();

            //    MessageBox.Show("Güncelleme işlemi başarılı bir şekilde yapıldı", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
