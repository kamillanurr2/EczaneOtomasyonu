﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class Muhasebe : Form
    {
        ECZANEEntities db = new ECZANEEntities();   
        public Muhasebe()
        {
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void Gelir()
        {
            var gelirler = from x in db.TBLGELIR
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.ACIKLAMA,
                               x.TUTAR
                           };
            dataGridView1.DataSource = gelirler.ToList();
            textBox11.Text = gelirler.Sum(x => x.TUTAR).ToString();
        }
        public void Gider()
        {

            var gelirler = from x in db.TBLGIDER
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.ACIKLAMA,
                               x.TUTAR
                           };
            dataGridView2.DataSource = gelirler.ToList();
            textBox11.Text = gelirler.Sum(x => x.TUTAR).ToString();
        }
        private void Muhasebe_Load(object sender, EventArgs e)
        {
            Gelir();
            Gider();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TBLGELIR yeni = new TBLGELIR();
            yeni.ACIKLAMA = tbaciklama.Text;
            yeni.TUTAR = Convert.ToDecimal(textBox1.Text);
            yeni.TARIH = Convert.ToDateTime(dateTimePicker1.Value.ToShortDateString());
            db.TBLGELIR.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("Kaydedildi");
            Gelir();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TBLGIDER yeni = new TBLGIDER();
            yeni.ACIKLAMA = textBox6.Text;
            yeni.TUTAR = Convert.ToDecimal(textBox5.Text);
            yeni.TARIH = Convert.ToDateTime(dateTimePicker6.Value.ToShortDateString());
            db.TBLGIDER.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("Kaydedildi");
            Gider();
        }

        private void dateTimePicker4_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLGIDER
                      where x.TARIH >= dateTimePicker5.Value && x.TARIH <= dateTimePicker4.Value
                      select new
                      {
                          x.ID,
                          x.ISLEM,
                          x.TARIH,
                          x.ACIKLAMA
                          
                      };
            dataGridView2.DataSource = deg.ToList();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLGELIR
                      where x.TARIH >= dateTimePicker3.Value && x.TARIH <= dateTimePicker2.Value
                      select new
                      {
                          x.ID,
                          x.ISLEM,
                          x.TARIH,
                          x.ACIKLAMA,
                          
                      };
            dataGridView1.DataSource = deg.ToList();
        }
    }
}
