﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class PersonelOdemeBilgiler : Form
    {
        public PersonelOdemeBilgiler()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        public int gelenperid;
        private void PersonelOdemeBilgiler_Load(object sender, EventArgs e)
        {
            //seçilen personelin id ve ad-soyadını yazdıralım
            label6.Text = gelenperid.ToString();

            var odemeyapilacakpersonelkim = db.TBLPERSONEL.Find(gelenperid);

            if (odemeyapilacakpersonelkim != null)
            {
                label7.Text = $"{odemeyapilacakpersonelkim.ADI}{odemeyapilacakpersonelkim.SOYADI}";
            }


          //  label7.Text = $"{odemeyapilacakpersonelkim.ADI}{odemeyapilacakpersonelkim.SOYADI}";

            //seçilen personelin önceki ödemelerini çekelim
            odemegoster();
            dataGridView2.Columns[0].Width = 50;
            dataGridView2.Columns[3].Width = 100;
            dataGridView2.Font = new Font("verdana", 10, FontStyle.Bold);
        }
        public void odemegoster()
        {
            var odemeler = from x in db.TBLPERSONELODEME
                           where x.ID == gelenperid
                           select new
                           {
                               x.ID,
                               x.ACIKLAMA,
                               x.TUR,
                               x.ISLEMTARIHI,
                               x.ODENEN
                           };
            dataGridView2.DataSource = odemeler.OrderByDescending(x => x.ISLEMTARIHI).ToList();

            textBox12.Text = odemeler.Sum(x => x.ODENEN).ToString();

            odemegoster();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TBLPERSONELODEME yo = new TBLPERSONELODEME();
            yo.ISLEMTARIHI = Convert.ToDateTime(dateTimePicker1.Value.ToString());
            yo.TUR = comboBox1.SelectedItem.ToString();
            yo.ODENEN = Convert.ToDecimal(txtodenen.Text);
            yo.ACIKLAMA = txtodenen.Text;
            yo.ID = gelenperid;
            db.TBLPERSONELODEME.Add(yo);
            db.SaveChanges();
            MessageBox.Show("Yeni ödeme kaydınız tamamlandı!");
            odemegoster();

            //bu ödeme kaydı kasaya gider olarak düşmeli
            TBLGIDER yeni = new TBLGIDER();
            yeni.ACIKLAMA = label6.Text + " 'a " + yo.TUR + " ödemesi yapıldı";
            yeni.TUTAR = yo.ODENEN;
            yeni.TARIH = yo.ISLEMTARIHI;
            db.TBLGIDER.Add(yeni);
            db.SaveChanges();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // tıklanan satır indexini bulalım
            int secilensatir = dataGridView2.SelectedCells[0].RowIndex;

            //bu satırdaki ödeme id yi alalım
            int secilenodemeid = Convert.ToInt32(dataGridView2.Rows[secilensatir].Cells[0].Value.ToString());

            DialogResult cevap = MessageBox.Show("Aktif ödeme kaydını silmek istediğinize emin misiniz?", "ÖDEME SİL", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (cevap == DialogResult.Yes)
            {
                var silinecekodemebul = db.TBLPERSONELODEME.Find(secilenodemeid);
                db.TBLPERSONELODEME.Remove(silinecekodemebul);
                db.SaveChanges();
                MessageBox.Show("Kayıt Silindi...");
                odemegoster();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            odemegoster();
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            //tıklanan satır indexini bulalım
            int secilensatir = dataGridView2.SelectedCells[0].RowIndex;

            //bu satırdaki ödeme id yi alalım
            string secilsecilentur = (dataGridView2.Rows[secilensatir].Cells[2].Value.ToString());

            var odemeler = from x in db.TBLPERSONELODEME
                           where x.ID == gelenperid & x.TUR == secilsecilentur
                           select new
                           {
                               x.ID,
                               x.ACIKLAMA,
                               x.TUR,
                               x.ISLEMTARIHI,                            
                               x.ODENEN
                           };
            dataGridView2.DataSource = odemeler.OrderByDescending(x => x.ISLEMTARIHI).ToList();

            textBox12.Text = odemeler.Sum(x => x.ODENEN).ToString();
        }
    }
}
