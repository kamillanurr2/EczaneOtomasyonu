﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class PersonelGuncelle : Form
    {
        public PersonelGuncelle()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        public int personelid;

        private void PersonelGuncelle_Load(object sender, EventArgs e)
        {
            var departmanlar = from x in db.TBLDEPARTMAN
                               where x.DURUM==true
                               select new
                               {
                                   x.ID,
                                   x.DEPARTMAN


                               };
            comboBox1.DisplayMember = "DEPARTMAN";
            comboBox1.ValueMember = "ID";
            comboBox1.DataSource = departmanlar;
            

            label13.Text = personelid.ToString();
            var kimmisbuidsigelen = db.TBLPERSONEL.Find(personelid);

            ad.Text = kimmisbuidsigelen.ADI;
            soyad.Text = kimmisbuidsigelen.SOYADI;
            tel.Text = kimmisbuidsigelen.TELEFON;
            adres.Text = kimmisbuidsigelen.ADRES;
            dateTimePicker1.Value = Convert.ToDateTime(kimmisbuidsigelen.ISEBASLAMATARIHI);
            tc.Text = kimmisbuidsigelen.TC;
            label11.Text = kimmisbuidsigelen.FOTOGRAF;
            maas.Text = kimmisbuidsigelen.MAAS.ToString();
            comboBox1.SelectedValue = kimmisbuidsigelen.DEPARTMAN;

            pictureBox2.ImageLocation = Application.StartupPath + "\\Resimler\\" + kimmisbuidsigelen.FOTOGRAF;

        }

        private void PersonelGuncelle_Load(object sender, EventArgs e, System.Windows.Forms.ComboBox comboBox1)
        {
            


        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var guncellenecekkayit = db.TBLPERSONEL.Find(personelid);

            //if (guncellenecekkayit.FOTOGRAF != label13.Text)
            //{
            //    //eski resmi sil
            //    System.IO.File.Delete(Application.StartupPath + "\\Resimler\\" + guncellenecekkayit.FOTOGRAF);
            //    //yeni resmi Resimler klasörüne kaydet
            //    pictureBox2.Image.Save(Application.StartupPath + "\\Resimler\\" + openFileDialog1.SafeFileName, System.Drawing.Imaging.ImageFormat.Jpeg);
            //}
            guncellenecekkayit.ADI = ad.Text;
            guncellenecekkayit.SOYADI = soyad.Text;
            guncellenecekkayit.MAAS = Convert.ToDecimal(maas.Text);
            guncellenecekkayit.TC = tc.Text;
            guncellenecekkayit.TELEFON = tel.Text;
            guncellenecekkayit.ADRES = adres.Text;
            guncellenecekkayit.ISEBASLAMATARIHI = dateTimePicker1.Value;
            guncellenecekkayit.DEPARTMAN = Convert.ToInt32(comboBox1.SelectedValue.ToString());
            guncellenecekkayit.FOTOGRAF = label13.Text;
            db.SaveChanges();
            MessageBox.Show("Kayıt Güncellendi");
            //Form1 deki personelgetir metodunu yenidençağıralım ki listedeki değişiklik görünsün
            ((Personeller)Application.OpenForms["Personeller"]).PersonelleriGetir();
            this.Close();

            //if (dataGridView1.SelectedRows.Count > 0)
            //{
            //    // Seçili satırın indeksini al
            //    int rowIndex = dataGridView1.SelectedRows[0].Index;

            //    // TextBox'lardaki verilerle DataGridView'deki satırı güncelle
            //    dataGridView1.Rows[rowIndex].Cells["Ad"].Value = ad.Text;
            //    dataGridView1.Rows[rowIndex].Cells["Soyad"].Value = soyad.Text;
            //    dataGridView1.Rows[rowIndex].Cells["Pozisyon"].Value = gorev.Text;
            //    dataGridView1.Rows[rowIndex].Cells["Pozisyon"].Value = tel.Text;
            //    dataGridView1.Rows[rowIndex].Cells["Pozisyon"].Value = mail.Text;
            //    dataGridView1.Rows[rowIndex].Cells["Pozisyon"].Value = adres.Text;
            //    dataGridView1.Rows[rowIndex].Cells["Pozisyon"].Value = tc.Text;
            //    dataGridView1.Rows[rowIndex].Cells["Pozisyon"].Value = maas.Text;



            //}
            //else
            //{
            //    MessageBox.Show("Lütfen güncellemek için bir satır seçin.");
            //}
        }

       

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //seçilen resmin adini labela yazdıralım; resmide picturebox ta gösterelim
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Image = Image.FromFile(openFileDialog1.FileName);
                label13.Text = openFileDialog1.SafeFileName;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label13.Text = "resimyok.png";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
