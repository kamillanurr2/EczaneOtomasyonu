﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class HesabaYaz : Form
    {
        public HesabaYaz()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        public int gelenid;

        private void HesabaYaz_Load(object sender, EventArgs e)
        {
            label2.Text = gelenid.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TBLHASTABORC b = new TBLHASTABORC();
            b.ACIKLAMA = textBox2.Text;
            b.BORC = Convert.ToDecimal(textBox1.Text);
            b.ID = Convert.ToInt32(label2.Text);
            b.TARIH = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            db.TBLHASTABORC.Add(b);
            db.SaveChanges();
            MessageBox.Show("Hesaba Yazıldı");

            ((Hasta)Application.OpenForms["Hasta"]).hastaborcgetir(gelenid);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
