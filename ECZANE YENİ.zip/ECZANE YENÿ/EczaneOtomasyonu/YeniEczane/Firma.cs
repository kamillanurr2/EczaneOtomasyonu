﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class Firma : Form
    {
        public Firma()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        private void button5_Click(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.TARIH >= dateTimePicker4.Value && x.TARIH <= dateTimePicker3.Value
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.FIRMADI,
                               x.TEL1,
                               x.TEL2,
                               x.ADRES,
                               x.MAIL,
                               x.WEB,
                               x.YETKILI,
                               x.ACIKLAMA,
                               x.UNVAN,

                           };

            dataGridView1.DataSource = degerler.ToList();
        }
        public void FirmaGetir(int id)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.ID == id
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.FIRMADI,
                               x.TEL1,
                               x.TEL2,
                               x.ADRES,
                               x.MAIL,
                               x.WEB,
                               x.YETKILI,
                               x.ACIKLAMA,
                               x.UNVAN
                           };
        dataGridView1.DataSource = degerler.ToList();
        }
    
        
        public void alınanurunler(int id)
        {
            var alur = from x in db.TBLFIRMAURUNAL
                       where x.FIRMAURUNID == id
                       select new
                       {
                           NO = x.FIRMAURUNID,
                           ALİM_TARİHİ = x.alımtarıhı,
                           FİRMA_ADI = x.FIRMA,
                           AÇIKLAMA = x.ACIKLAMA,
                           URUN_AD = x.URUNADI,
                           NEKADAR = x.NEKADAR,
                           FIYAT = x.FIYAT
                       };
            dataGridView2.DataSource = alur.OrderBy(x => x.URUN_AD).ToList();
            dataGridView2.RowHeadersVisible = false;
            textBox12.Text = alur.Sum(X => X.FIYAT).ToString();

            dataGridView2.Columns[0].Visible = false;


            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            FirmaEkle pe = new FirmaEkle();
            pe.ShowDialog();
            //FirmaEkle form = new FirmaEkle();
            //form.TopLevel = false;
            //panel1.Controls.Add(form);
            //form.Show();
            //form.TopMost = true;
            //form.BringToFront();
            //FirmaEkle F = new FirmaEkle();
            //F.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FirmaOdeme()
        {
            var odeme = from x in db.TBLFIRMAODEME
                        select new
                        {
                            x.TBLFIRMA.FIRMADI,
                            x.ACIKLAMA,
                            x.TUTAR,
                            x.TARIH,

                        };
            dataGridView2.DataSource = odeme.ToList();

        }
        private void FirmaGetir()
        {
            var firma = from x in db.TBLFIRMA
                        select new
                        {
                            x.ID,
                            x.TARIH,
                            x.FAX,
                            x.ACIKLAMA,
                            x.ADRES,
                            x.FIRMADI,
                            x.MAIL,
                            x.TBLFIRMAODEME,

                        };
            dataGridView1.DataSource = firma.ToList();
                        
        }

        private void Firma_Load(object sender, EventArgs e)
        {
            FirmaGetir();
            FirmaOdeme();
        }

      

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.FIRMADI.ToLower().Contains(textBox11.Text.ToLower())
                           select new
                           {
                               x.ID,
                               x.TARIH,
                               x.FIRMADI,
                               x.TEL1,
                               x.TEL2,
                               x.ADRES,
                               x.MAIL,
                               x.WEB,
                               x.YETKILI,
                               x.ACIKLAMA,
                               x.UNVAN

                           };

            dataGridView1.DataSource = degerler.ToList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FirmaGuncelle pe = new FirmaGuncelle();
            pe.TopLevel = false;
            panel1.Controls.Add(pe);
        //    pe.firmagetir = Convert.ToInt32(label10.Text);
            pe.Show();
            pe.TopMost = true;
            pe.BringToFront();
        }
        int secilenid;
        private void button3_Click(object sender, EventArgs e)
        {
            var SİLID = secilenid;
            var silincek = db.TBLFIRMA.Find(SİLID);
            DialogResult cevap = MessageBox.Show(silincek.ID + " nolu kaydı silmek istediğinize eminmisiniz ", " Firma sil ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (cevap == DialogResult.Yes)
            {
                db.TBLFIRMA.Remove(silincek);
                db.SaveChanges();

                MessageBox.Show("SİLİNDİ");
                FirmaGetir();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker6_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLFIRMA
                      where x.TARIH >= dateTimePicker6.Value && x.TARIH <= dateTimePicker5.Value
                      select new
                      {
                          x.ID,
                          x.FIRMADI,
                          x.TARIH,
                          x.ADRES,
                          x.TBLFIRMAODEME,
                      };
            dataGridView2.DataSource = deg.ToList();
        }

        private void dateTimePicker4_ValueChanged(object sender, EventArgs e)
        {
            var deg = from x in db.TBLFIRMA
                      where x.TARIH >= dateTimePicker4.Value && x.TARIH <= dateTimePicker3.Value
                      select new
                      {
                          x.ID,
                          x.FIRMADI,
                          x.TARIH,
                          x.ADRES
                          
                      };
            dataGridView1.DataSource = deg.ToList();
        }
    }
}
