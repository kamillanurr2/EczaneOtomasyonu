﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class DoktorEkle : Form
    {
        public DoktorEkle()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        //public void DoktorListele()
        //{
        //    var degerler = from x in db.TBLDOKTOR
        //                   select new
        //                   {
        //                       x.ID,
        //                       x.DOKTORADISOYADI,
        //                       x.HASTANE,
        //                       x.DIPLOMA
        //                   };



        //}
        private void btndoktorekle_Click(object sender, EventArgs e)
        {

            TBLDOKTOR yeni = new TBLDOKTOR();
            yeni.DOKTORADISOYADI = txtAdi.Text;
            yeni.DOKTORADISOYADI = txtSoyad.Text;
            yeni.HASTANE = txthastane.Text;
            yeni.ALANI = txtAlanı.Text;
            
            db.TBLDOKTOR.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("Yeni doktor kaydı tamamlandı");

            ((Doktor)Application.OpenForms["Doktor"]).DoktorListele();

            this.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DoktorEkle_Load(object sender, EventArgs e)
        {
            

        }

        private void txtAdi_MouseClick(object sender, MouseEventArgs e)
        {
            txtAdi.SelectAll();
        }

        private void txtSoyad_MouseClick(object sender, MouseEventArgs e)
        {
            txtSoyad.SelectAll();
        }

        private void txthastane_MouseClick(object sender, MouseEventArgs e)
        {
            txthastane.SelectAll();
        }

        private void txtAlanı_MouseClick(object sender, MouseEventArgs e)
        {
            txtAlanı.SelectAll();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

        
    
}
