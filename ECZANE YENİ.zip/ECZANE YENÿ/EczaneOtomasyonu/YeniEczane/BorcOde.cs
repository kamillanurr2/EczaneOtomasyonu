﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class BorcOde : Form
    {
        public BorcOde()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        public int gelenid;
        private void BorcOde_Load(object sender, EventArgs e)
        {
            label2.Text =gelenid.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TBLHASTAODEME hasta = new TBLHASTAODEME();
            hasta.ACIKLAMA = textBox2.Text;
            hasta.ODENEN = Convert.ToDecimal(textBox1.Text);
            hasta.HASTA = Convert.ToInt32(label2.Text);
            hasta.ODEMETARIHI = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            db.TBLHASTAODEME.Add(hasta);
            db.SaveChanges();
            MessageBox.Show("Ödeme Kaydı Yapıldı");

            //bu ödeme kasaya gelir olarak kaydedilsin
            TBLGELIR yeni = new TBLGELIR();
            string hastakimm = db.TBLHASTA.Find(hasta.HASTA).AD + " " + db.TBLHASTA.Find(hasta.HASTA).SOYAD;

            yeni.ACIKLAMA = hastakimm + " Ödeme Yaptı";
            yeni.TUTAR = hasta.ODENEN;
            yeni.TARIH = hasta.ODEMETARIHI;
            db.TBLGELIR.Add(yeni);
            db.SaveChanges();


            ((Hasta)Application.OpenForms["Hasta"]).hastaborcgetir(gelenid);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
