﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace YeniEczane
{
    public partial class KasaÇıkış : Form
    {
        public KasaÇıkış()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();

        private void KASA()
        {
            var kasacikis = from x in db.TBLKASA
                            select x;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            TBLKASA KS = new TBLKASA();
            KS.TARIH = Convert.ToDateTime(dateTimePicker1.Value.ToString());
            KS.MIKTAR = Convert.ToDecimal(textBox2.Text);
            KS.ACIKLAMA = textBox1.Text;
            KS.ISLEM = true;
            db.TBLKASA.Add(KS);
            db.SaveChanges();

            //((Kasa)System.Windows.Forms.Application.OpenForms["Kasa"]).KASA();
            
            //////////////////////////////////////////////////////////////
            TBLGIDER yeni = new TBLGIDER();

            yeni.ISLEM = "Para Ödendi";
            yeni.YERADI = "KASA";

            yeni.ACIKLAMA = KS.ACIKLAMA;
         //   yeni.MIKTAR = Convert.ToDecimal(KS.MIKTAR);
            yeni.TARIH = Convert.ToDateTime(KS.TARIH);
            db.TBLGIDER.Add(yeni);
            db.SaveChanges();

            MessageBox.Show("YENİ PARA ÇIKIŞINIZ TAMAMLANDI");
            this.Close();
        }

        private void KasaÇıkış_Load(object sender, EventArgs e)
        {
            KASA();
        }
    }
}
