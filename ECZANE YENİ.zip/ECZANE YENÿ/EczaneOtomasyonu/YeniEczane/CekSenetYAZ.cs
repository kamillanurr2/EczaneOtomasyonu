﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class CekSenetYAZ : Form
    {
        public CekSenetYAZ()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        public int firmaid;
        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" & textBox2.Text != "")
            {
                TBLCEKSENET yenı = new TBLCEKSENET();
                yenı.FIRMA = Convert.ToInt32(label7.Text);
                yenı.TUTAR = Convert.ToDecimal(textBox1.Text);
                yenı.ACIKLAMA = textBox2.Text;
                yenı.YAZMATARIHI = Convert.ToDateTime(dateTimePicker5.Value.ToShortDateString());
                yenı.ODEMETARIHI = Convert.ToDateTime(dateTimePicker6.Value.ToShortDateString());

                yenı.DURUMU = false;
                if (radioButton1.Checked) yenı.TUR = "ÇEK";
                if (radioButton2.Checked) yenı.TUR = "SENET";

                db.TBLCEKSENET.Add(yenı);
                db.SaveChanges();

                ((CekSenet)Application.OpenForms["CekSenet"]).ceksenet();

                this.Close();


            }
            else
            {
                MessageBox.Show(" tutar yazmalı ve fırma girmelisin");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLFIRMA
                           where x.FIRMADI.ToLower().Contains(textBox3.Text.ToLower())
                           select new
                           {
                               x.FIRMADI,
                               x.ID
                           };
            dataGridView2.DataSource = degerler.ToList();

            if (textBox3.Text == "")
            {
                degerler.ToList();
            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int secılensatır = dataGridView2.SelectedCells[0].RowIndex;
            int secılenıd = Convert.ToInt32(dataGridView2.Rows[secılensatır].Cells[0].Value.ToString());

            string secılenfırma = dataGridView2.Rows[secılensatır].Cells[1].Value.ToString();
            label7.Text = secılenıd.ToString();
            textBox4.Text = secılenfırma.ToString();
        }

        private void CekSenetYAZ_Load(object sender, EventArgs e)
        {
            var degerler = from x in db.TBLFIRMA
                           select new
                           {
                               x.ID,
                               x.FIRMADI
                           };
            dataGridView2.DataSource = degerler.ToList();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dateTimePicker6_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker5_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
