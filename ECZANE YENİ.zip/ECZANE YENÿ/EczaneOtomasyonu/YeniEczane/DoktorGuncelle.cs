﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class DoktorGuncelle : Form
    {
        public DoktorGuncelle()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (AD.Text == "" || SOYAD.Text == "" || txthastane.Text == "" || İŞEB.Text == "")
            {
                MessageBox.Show("Lütfen alanları boş geçmeyiniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }

            else
            {

                int degeral = int.Parse(label10.Text);
                var bul = db.TBLDOKTOR.Find(degeral);
                bul.DOKTORADISOYADI = AD.Text;
                bul.DOKTORADISOYADI = SOYAD.Text;
                bul.HASTANE = txthastane.Text;
                bul.ALANI = İŞEB.Text;

                db.SaveChanges();

                MessageBox.Show("Güncelleme işlemi başarılı bir şekilde yapıldı", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void DoktorGuncelle_Load(object sender, EventArgs e)
        {
            
            AD.Text = AD.Text;
            SOYAD.Text = SOYAD.Text;
            txthastane.Text = txthastane.Text;
            İŞEB.Text = İŞEB.Text;
            
        }
    }
}
