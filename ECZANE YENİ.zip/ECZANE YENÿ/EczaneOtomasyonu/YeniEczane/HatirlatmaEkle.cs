﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YeniEczane
{
    public partial class HatirlatmaEkle : Form
    {
        ECZANEEntities db = new ECZANEEntities();   
        public HatirlatmaEkle()
        {
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void Hatirlatma()
        {
            var hatirlaticii = from x in db.TBLHATIRLATMA
                               select new
                               {
                                   x.HATIRLATMATARIHI,
                                   x.KAYITTARIHI,
                                   x.ACIKLAMA,
                                   x.DURUMU,
                                   x.TURU
                               };
            
        }
        private void button3_Click(object sender, EventArgs e)
        {
            TBLHATIRLATMA yeni = new TBLHATIRLATMA();
            yeni.TURU = textBox1.Text;
            yeni.KAYITTARIHI =Convert.ToDateTime( dateTimePicker1.Text);
            yeni.HATIRLATMATARIHI = Convert.ToDateTime(dateTimePicker2.Text);
            yeni.ACIKLAMA = textBox2.Text;
            yeni.DURUMU = comboBox1.Text;

            db.TBLHATIRLATMA.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("Yeni hatırlatma kaydı tamamlandı");

           // ((Hatırlatıcı)Application.OpenForms["Hatırlatıcı"]).(Hatirlatma);
         
            this.Close();
        }

        private void HatirlatmaEkle_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
