﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class FirmaGuncelle : Form
    {
        public FirmaGuncelle()
        {
            InitializeComponent();
        }
        ECZANEEntities db = new ECZANEEntities();
        public int fırmagetırID;
        private void FirmaGuncelle_Load(object sender, EventArgs e)
        {
            label6.Text = fırmagetırID.ToString();


            var ilkayıt = db.TBLFIRMA.Find(fırmagetırID);
            AD.Text = ilkayıt.FIRMADI;
            tel1t.Text = ilkayıt.TEL1;
            tel2tt.Text = ilkayıt.TEL2;
            faxt.Text = ilkayıt.FAX.ToString();
            maılt.Text = ilkayıt.MAIL;
            unvant.Text = ilkayıt.UNVAN;
            webt.Text = ilkayıt.WEB;
            acıklamat.Text = ilkayıt.ACIKLAMA;
            yetklılıt.Text = ilkayıt.YETKILI;
            ADREST.Text = ilkayıt.ADRES;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var gk = db.TBLFIRMA.Find(fırmagetırID);
            gk.FIRMADI = AD.Text;
            gk.TEL1 = tel1t.Text;
            gk.TEL2 = tel2tt.Text;
            gk.ACIKLAMA = acıklamat.Text;
            gk.ADRES = ADREST.Text;
            gk.FAX =Convert.ToInt32(faxt.Text);
            gk.MAIL = maılt.Text;
            gk.WEB = webt.Text;
            gk.YETKILI = yetklılıt.Text;
            gk.UNVAN = unvant.Text;


            db.SaveChanges();
            MessageBox.Show("FIRMA GÜNCELLENDİ");

            Firma fe = new Firma();
            fe.ShowDialog();

            //((Firma)Application.OpenForms["Firma"]).FirmaGetir();
            //this.Close();
        }
    }
}
