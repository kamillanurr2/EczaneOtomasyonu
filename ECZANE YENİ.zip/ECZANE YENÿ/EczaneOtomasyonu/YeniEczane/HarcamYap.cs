﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace YeniEczane
{
    public partial class HarcamYap : Form
    { 
        ECZANEEntities db = new ECZANEEntities();   
        public HarcamYap()
        {
            InitializeComponent();
        }
        public void harcamayap()
        {
            var harcama = from x in db.TBLHARCAMA
                          select new
                          {
                              x.HARCAMATARIHI,
                              x.HARCAMAID,
                              x.MIKTAR,
                              x.ACIKLAMA,
                              x.HARCAMAYAPILANYER
                          };
           

        }
        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HarcamYap_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            TBLHARCAMA yeni = new TBLHARCAMA();
            yeni.HARCAMATARIHI = Convert.ToDateTime(dateTimePicker1.Value.ToString());
            yeni.HARCAMAYAPILANYER = textBox4.Text;
            yeni.ODEMETURU = comboBox1.SelectedItem.ToString();
            yeni.MIKTAR = Convert.ToInt32(textBox1.Text);
            yeni.ACIKLAMA = textBox2.Text;

            db.TBLHARCAMA.Add(yeni);
            db.SaveChanges();
            MessageBox.Show("yeni bir harcama eklendi");

            ((GunlukHarcama)Application.OpenForms["GunlukHarcama"]).gunlukharcama();
            this.Close();

            //TBLGUNLUKHARCAMALAR y = new TBLGUNLUKHARCAMALAR();
            //y.HARCAMATARIHI = Convert.ToDateTime(dateTimePicker1.Value.ToString());
            //y.ODEMETURU = comboBox1.SelectedItem.ToString();
            //y.HARCAMAYAPILANYER = textBox1.Text;
            //y.MIKTAR = Convert.ToDecimal(textBox2.Text.ToString());
            //y.ACIKLAMA = textBox2.Text.ToString();


            //db.TBLGUNLUKHARCAMALAR.Add(y);
            //db.SaveChanges();
            //MessageBox.Show(" YENİ HARCAMA BİLGİSİ GİRİLDİ ");
            ////////////////////////////////////////
            //TBLGIDER yeni = new TBLGIDER();
            //string GHARCAMA = db.TBLGUNLUKHARCAMALAR.Find(y.HARCAMAID).HARCAMAYAPILANYER;
           
            //yeni.ACIKLAMA = GHARCAMA + " ÖDEME YAPILDI";
            //yeni.TUTAR= Convert.ToDecimal(y.MIKTAR);
            //yeni.TARIH = Convert.ToDateTime(y.HARCAMATARIHI);
            //db.TBLGIDER.Add(yeni);
            //db.SaveChanges();

            //////////////////////////////////////////
            ///    
            

            //////////////////////////////////////////

            

        }
    }
}
